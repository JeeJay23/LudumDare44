import math
import random
from contextlib import contextmanager
import bpy
from mathutils import Vector, Quaternion, Matrix
from . import selector
from . import widget
from . import gizmo
from . import object_pool
from . import ray_cast
from . import utils


class BuilderState:

    def __init__(self):
        self.object_index = 0
        self.object = None
        self.children = []
        self.rotation = None
        self.scale = None
        self.instancers = []
        self.instancer_objs = []

    def apply_object(self):
        self.object = None
        self.children = []
        if len(self.instancers) > 0:
            object_pool.make_instancers_real(self.instancers)
            self.clear_instancers()
        ray_cast.reset()

    def clear(self):
        self.clear_object()
        self.clear_instancers()

    def clear_object(self):
        utils.remove_objects_in(self.children)
        self.object = None
        self.children = []

    def clear_instancers(self):
        meshes = [instancer.data for instancer in self.instancers if instancer.type == 'MESH']
        utils.remove_objects_in(self.instancer_objs)
        utils.remove_objects_in(self.instancers)
        self.instancers = []
        self.instancer_objs = []
        for mesh in meshes:
            if mesh.users == 0:
                bpy.data.meshes.remove(mesh)

    def get_object_rotation(self):
        return self.rotation

    def get_object_scale(self):
        return self.scale

    def is_empty(self):
        return self.object is None and len(self.instancers) == 0

    def placing_object(self):
        return self.object is not None

    def placing_instancers(self):
        return len(self.instancers) > 0

    def get_object_index(self):
        return self.object_index

    def get_object(self):
        return self.object

    def iter_objects(self):
        yield from self.children

    def iter_instancers(self):
        yield from self.instancers

    def iter_instancer_objs(self):
        yield from self.instancers
        yield from self.instancer_objs

    def get_single_object(self):
        indices = object_pool.get_object_indices(1)
        self.object_index = indices[0]
        self.object, self.children = object_pool.get_object(indices[0])
        self.rotation = self.object.rotation_euler.copy()
        self.scale = self.object.scale.copy()

    def update_instancers(self, instancers_matrices):
        if len(self.instancers) > 0:
            object_pool.create_instancers(self.instancers, instancers_matrices)
        else:
            instancers = [None for _ in range(object_pool.get_count())]
            self.instancers, self.instancer_objs = object_pool.create_instancers(instancers, instancers_matrices)


class BuilderUI(widget.Base):

    def __init__(self):
        super().__init__()


class Builder:

    def __init__(self):
        self.builder = [GridBuilder(), SnapSurfaceBuilder(), PaintBuilder()]
        self.key_to_mode = {'ONE': '0', 'TWO': '1', 'THREE': '2'}

        self.mode = -1

    def start(self):
        for builder in self.builder:
            builder.reset()
        mode = -1
        self.check_mode()
        pivot_selector.reset()

    def close(self):
        if self.mode != -1:
            self.builder[self.mode].exit()
        self.mode = -1
        builder_state.clear()
        object_pool.clear()
        ray_cast.reset()

    def check_mode(self):
        settings = bpy.context.scene.level_builder.builder
        mode = int(settings.mode)
        if self.mode != mode:
            if self.mode != -1:
                self.builder[self.mode].exit()
            self.mode = mode
            builder_state.clear()
            self.builder[self.mode].start()

    def suspend(self, x, y, event):
        if self.mode != -1:
            self.builder[self.mode].suspend(x, y, event)

    def draw(self):
        builder_ui.draw()

    def draw_gizmo(self):
        if self.mode != -1:
            self.builder[self.mode].draw_gizmo()
        pivot_selector.draw_gizmo()

    def handle_event(self, x, y, event):
        settings = bpy.context.scene.level_builder.builder

        builder_ui.handle_event(x, y, event)
        pivot_selector.handle_event(x, y, event)
        if pivot_selector.selecting():
            return

        self.check_mode()
        self.builder[self.mode].handle_event(x, y, event)

        if event.value == 'PRESS':
            if event.type in self.key_to_mode:
                settings.mode = self.key_to_mode[event.type]
                utils.get_bpy_area('PROPERTIES').tag_redraw()

            if event.type == 'SPACE':
                selector.reset()
                self.close()


class GridBuilder:

    def __init__(self):
        self.axis = [(1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0)]
        self.key_to_dir = {'X': 0, 'Y': 1, 'Z': 2}
        self.key_to_move = {'UP_ARROW': 1, 'DOWN_ARROW': -1}
        self.key_to_rotate = {'LEFT_ARROW': 1, 'RIGHT_ARROW': -1}
        self.key_to_scale = {'INSERT': 1, 'DEL': -1}
        self.key_to_grid_size = {'NUMPAD_PLUS': 1, 'NUMPAD_MINUS': -1}
        self.gizmo = [gizmo.Grid(), gizmo.Checker()]

        self.location = Vector((0.0, 0.0, 0.0))
        self.rotation = Quaternion()
        self.scale = 0

        self.seed = None
        self.fill = False
        self.fill_start = self.fill_current = (0, 0)
        self.fill_end = None
        self.fill_snap = None
        self.instancers_matrices = []

    def reset(self):
        self.rotation = Quaternion()
        self.scale = 0

    def apply(self, x, y, event):
        self.location = self.get_location(x, y, event.ctrl)
        if builder_state.placing_object():
            self.update_object()
        if builder_state.placing_instancers():
            self.fill_end = None
            self.fill_object()

    def start(self):
        self.reset()

    def suspend(self, x, y, event):
        pass

    def exit(self):
        pass

    def update_object(self):
        quat = self.rotation @ builder_state.get_object_rotation().to_quaternion()
        rotation_matrix = quat.to_matrix().to_4x4()
        scale = builder_state.get_object_scale() + Vector((1.0, 1.0, 1.0)) * self.scale
        scale_matrix = Matrix.Identity(4)
        scale_matrix[0][0] = scale.x
        scale_matrix[1][1] = scale.y
        scale_matrix[2][2] = scale.z
        matrix = Matrix.Translation(self.location) @ rotation_matrix @ scale_matrix
        matrix @= Matrix.Translation(pivot_selector.get_offset())
        builder_state.get_object().matrix_world = matrix

    def draw_gizmo(self):
        settings = bpy.context.scene.level_builder.builder
        mode = int(settings.grid_mode)
        if mode != -1:
            self.gizmo[mode % 2].draw()

    def handle_event(self, x, y, event):
        settings = bpy.context.scene.level_builder.builder

        if builder_state.is_empty():
            builder_state.get_single_object()
            self.apply(x, y, event)

        if pivot_selector.selecting():
            return

        if event.value == 'PRESS':
            if event.type in ('RET', 'LEFTMOUSE'):
                builder_state.apply_object()

            if event.type == 'R':
                self.reset()
                self.apply(x, y, event)

            if event.type in ('WHEELUPMOUSE', 'WHEELDOWNMOUSE'):
                if builder_state.placing_object():
                    builder_state.clear_object()
                    builder_state.get_single_object()
                    self.apply(x, y, event)

            if event.type == 'N':
                self.seed += random.randrange(2e16)
                self.apply(x, y, event)

            if event.type in self.key_to_dir.keys():
                settings.grid_direction = str(self.key_to_dir[event.type])
                utils.get_bpy_area('PROPERTIES').tag_redraw()

            if event.type in self.key_to_move.keys():
                direction = int(settings.grid_direction)
                move = self.key_to_move[event.type] * settings.grid_size[direction]
                settings.grid_location[direction] += move
                if event.ctrl:
                    location = settings.grid_location[direction]
                    location = round(location / settings.grid_size[direction]) * settings.grid_size[direction]
                    settings.grid_location[grid_direction] = location
                if builder_state.placing_object():
                    builder_state.get_object().location[direction] = settings.grid_location[direction]
                else:
                    self.fill_end = None
                    self.fill_object()
                utils.get_bpy_area('PROPERTIES').tag_redraw()

            if event.type in self.key_to_scale.keys():
                scale = self.key_to_scale[event.type] * settings.grid_scale
                self.scale += scale
                if builder_state.placing_object():
                    self.update_object()
                else:
                    self.update_instancers()

            if event.type in self.key_to_grid_size.keys():
                size = self.key_to_grid_size[event.type] * settings.grid_step
                m1 = [event.alt or event.ctrl, event.alt or event.shift, event.shift or event.ctrl]
                m1 = not (event.shift or event.ctrl or event.alt)
                m2 = [event.shift, event.ctrl, event.alt]
                if builder_state.placing_object():
                    for i in range(3):
                        grid_size = settings.grid_size[i] + size
                        if grid_size != 0 and (m1 or m2[i]):
                            settings.grid_size[i] = grid_size
                    self.apply(x, y, event)
                else:
                    for i in range(3):
                        grid_size = self.fill_snap[i] + size
                        if grid_size != 0 and (m1 or m2[i]):
                            self.fill_snap[i] = grid_size
                    self.fill_end = None
                    self.fill_object()
                utils.get_bpy_area('PROPERTIES').tag_redraw()

            if event.type in self.key_to_rotate.keys():
                axis = int(settings.grid_direction)
                axis += 1 if event.shift else 0
                axis += 2 if event.ctrl else 0
                axis = Vector(self.axis[axis % 3])
                angle = self.key_to_rotate[event.type] * settings.grid_rotate
                quat = Quaternion(axis, angle)
                self.rotation = quat @ self.rotation
                if builder_state.placing_object():
                    self.update_object()
                else:
                    self.update_instancers()

        if event.type == 'MOUSEMOVE':
            self.mouse_move(x, y, event)

    def mouse_move(self, x, y, event):
        self.location = self.get_location(x, y, event.ctrl)

        if event.shift:
            if not self.fill:
                self.start_fill_object()
            else:
                self.fill_current = self.location
        elif self.fill:
            self.remove_fill_object()
            return

        if self.fill:
            self.fill_object()
        else:
            self.update_object()

    def start_fill_object(self):
        settings = bpy.context.scene.level_builder.builder
        self.fill = True
        self.fill_start = self.fill_current = self.location
        self.fill_snap = Vector(settings.grid_size)
        builder_state.clear_object()

    def remove_fill_object(self):
        self.fill = False
        self.seed = self.fill_end = None
        builder_state.clear_instancers()

    def fill_object(self):
        if self.fill_end == self.fill_current:
            return

        settings = bpy.context.scene.level_builder.builder
        self.fill_end = self.fill_current

        d = int(settings.grid_direction)
        if d == 0:
            w = abs(self.fill_end.y - self.fill_start.y) / self.fill_snap.y
            h = abs(self.fill_end.z - self.fill_start.z) / self.fill_snap.z
            x_step = self.fill_snap.y if (self.fill_end.y > self.fill_start.y) else -self.fill_snap.y
            x_step = Vector((0.0, x_step, 0.0))
            y_step = self.fill_snap.z if (self.fill_end.z > self.fill_start.z) else -self.fill_snap.z
            y_step = Vector((0.0, 0.0, y_step))
        elif d == 1:
            w = abs(self.fill_end.x - self.fill_start.x) / self.fill_snap.x
            h = abs(self.fill_end.z - self.fill_start.z) / self.fill_snap.z
            x_step = self.fill_snap.x if (self.fill_end.x > self.fill_start.x) else -self.fill_snap.x
            x_step = Vector((x_step, 0.0, 0.0))
            y_step = self.fill_snap.z if (self.fill_end.z > self.fill_start.z) else -self.fill_snap.z
            y_step = Vector((0.0, 0.0, y_step))
        else:
            w = abs(self.fill_end.x - self.fill_start.x) / self.fill_snap.x
            h = abs(self.fill_end.y - self.fill_start.y) / self.fill_snap.y
            x_step = self.fill_snap.x if (self.fill_end.x > self.fill_start.x) else -self.fill_snap.x
            x_step = Vector((x_step, 0.0, 0.0))
            y_step = self.fill_snap.y if (self.fill_end.y > self.fill_start.y) else -self.fill_snap.y
            y_step = Vector((0.0, y_step, 0.0))
        w = math.floor(w) + 1
        h = math.floor(h) + 1

        with random_state(self.seed) as (seed, a, b, c):
            self.seed = seed

            indices = []
            object_pool.restart_seq_index()
            for i in range(h):
                random.seed(a=a + b * i)
                indices.append(object_pool.get_object_indices(w))
            object_pool.restore_seq_index()

            normal = Vector((0.0, 0.0, 1.0))

            loc_y = self.fill_start.copy()
            self.instancers_matrices = [[] for _ in range(object_pool.get_count())]
            for y in range(h):
                loc = loc_y.copy()
                for x, index in enumerate(indices[y]):
                    if index >= 0:
                        index %= object_pool.get_count()
                        random.seed(a=a + b * y + c * x)
                        matrix = object_pool.get_randomness_matrix(index, loc, normal, -1)
                        self.instancers_matrices[index].append(matrix)
                    loc += x_step
                loc_y += y_step

        self.update_instancers()

    def update_instancers(self):
        m = self.rotation.to_matrix().to_4x4() @ Matrix.Scale(1 + self.scale, 4)
        instancers_matrices = []
        for i, matrices in enumerate(self.instancers_matrices):
            instancers_matrices.append([matrix @ m @ Matrix.Translation(pivot_selector.get_offset(i)) for matrix in matrices])
        builder_state.update_instancers(instancers_matrices)

    def get_location(self, x, y, half):
        settings = bpy.context.scene.level_builder.builder
        snap_x = settings.grid_size[0] * (0.5 if half else 1.0)
        snap_y = settings.grid_size[1] * (0.5 if half else 1.0)
        snap_z = settings.grid_size[2] * (0.5 if half else 1.0)

        plane_co = Vector(settings.grid_location)
        plane_no = Vector(self.axis[int(settings.grid_direction)])
        loc = utils.get_point_in_plane(x, y, plane_co, plane_no)
        if loc is not None:
            loc.x = round(loc.x / snap_x) * snap_x
            loc.y = round(loc.y / snap_y) * snap_y
            loc.z = round(loc.z / snap_z) * snap_z
            loc[int(settings.grid_direction)] = settings.grid_location[int(settings.grid_direction)]
            return loc

        return self.location


class SnapSurfaceBuilder:

    def __init__(self):
        self.key_to_dir = {'X': 0, 'Y': 1, 'Z': 2}
        self.key_to_offset = {'UP_ARROW': 1, 'DOWN_ARROW': -1}
        self.key_to_rotate = {'LEFT_ARROW': 1, 'RIGHT_ARROW': -1}
        self.key_to_scale = {'INSERT': 1, 'DEL': -1}

        self.location = Vector((0.0, 0.0, 0.0))
        self.quat = Quaternion()
        self.normal = Vector((0.0, 0.0, 1.0))

        self.mouse_x = self.mouse_y = self.current_x = self.current_y = 0
        self.reset()

    def reset(self):
        self.offset = self.angle = 0
        self.scale = 1
        self.random_offset = Vector((0.0, 0.0, 0.0))
        self.random_rotation = Quaternion()
        self.random_scale = Vector((1.0, 1.0, 1.0))
        self.scale_dict = {}

        self.paint_bvhtree = None
        self.paint_ignore = []
        self.paint_location = None
        self.paint_vector = None
        self.paint_rotation = Quaternion()

    def apply(self, x, y, event):
        self.current_x = self.mouse_x = x
        self.current_y = self.mouse_y = y
        self.snap(self.current_x, self.current_y)
        self.update_object()

    def start(self):
        self.reset()

    def suspend(self, x, y, event):
        self.current_x = self.mouse_x = x
        self.current_y = self.mouse_y = y

    def exit(self):
        pass

    def draw_gizmo(self):
        pass

    def handle_event(self, x, y, event):
        settings = bpy.context.scene.level_builder.builder

        if builder_state.is_empty():
            builder_state.get_single_object()
            self.scale_dict = {obj: obj.scale.copy() for obj in builder_state.iter_objects()}
            self.apply(x, y, event)

        if pivot_selector.selecting():
            return

        if event.type == 'MOUSEMOVE':
            self.mouse_move(x, y, event)
            if self.paint_bvhtree is not None:
                self.paint()

        if event.value == 'PRESS':
            if event.type in ('RET', 'LEFTMOUSE'):
                if self.paint_bvhtree is None:
                    self.paint()

            if event.type == 'R':
                self.reset()
                self.apply(x, y, event)

            if event.type in ('WHEELUPMOUSE', 'WHEELDOWNMOUSE'):
                if builder_state.placing_object():
                    builder_state.clear_object()
                    builder_state.get_single_object()
                    self.apply(x, y, event)

            if event.type == 'N':
                index = builder_state.get_object_index()
                matrix = object_pool.get_randomness_matrix(index, self.location, self.normal, -1)
                self.random_offset = self.location - matrix.to_translation()
                self.random_rotation = matrix.to_quaternion()
                self.random_scale = matrix.to_scale()
                self.update_object()

            if event.type in self.key_to_dir.keys():
                align = self.key_to_dir[event.type]
                if event.shift:
                    align += 3
                settings.snap_align_object = str(align)
                utils.get_bpy_area('PROPERTIES').tag_redraw()
                self.snap(self.current_x, self.current_y)
                self.update_object()

            if event.type in self.key_to_offset.keys():
                self.offset += self.key_to_offset[event.type] * settings.snap_offset
                self.update_object()

            if event.type in self.key_to_scale.keys():
                self.scale += self.key_to_scale[event.type] * settings.snap_scale
                self.update_object()

            if event.type in self.key_to_rotate.keys():
                self.angle += self.key_to_rotate[event.type] * settings.snap_rotate
                self.update_object()

        if event.value == 'RELEASE':
            if event.type in ('RET', 'LEFTMOUSE'):
                self.paint_bvhtree = None
                self.paint_ignore = []
                self.paint_rotation = Quaternion()

    def update_object(self):
        matrix = self.get_matrix()
        if self.paint_bvhtree is not None:
            for obj in builder_state.iter_objects():
                obj.scale = self.scale_dict[obj]
            bpy.context.scene.update()
        builder_state.get_object().matrix_world = matrix

    def get_matrix(self):
        settings = bpy.context.scene.level_builder.builder

        location = self.location + self.random_offset + self.normal.normalized() * self.offset
        quat = Quaternion(self.normal, self.angle)
        quat = quat @ self.random_rotation @ self.quat
        if settings.snap_stroke_direction:
            quat = self.paint_rotation @ quat
        rotation_matrix = quat.to_matrix().to_4x4()
        scale = self.random_scale * self.scale
        scale_matrix = Matrix.Identity(4)
        scale_matrix[0][0] = scale.x
        scale_matrix[1][1] = scale.y
        scale_matrix[2][2] = scale.z
        matrix = Matrix.Translation(location) @ rotation_matrix @ scale_matrix
        matrix @= Matrix.Translation(pivot_selector.get_offset())
        return matrix

    def mouse_move(self, x, y, event):
        move_x = x - self.mouse_x
        move_y = y - self.mouse_y
        self.mouse_x = x
        self.mouse_y = y

        move = (move_x if abs(move_x) > abs(move_y) else move_y) / 100
        if event.shift:
            self.offset += move
        elif event.ctrl:
            self.scale += move
        elif event.alt:
            self.angle += move
        else:
            self.current_x += move_x
            self.current_y += move_y
            self.snap(self.current_x, self.current_y)

        self.update_object()

    def paint(self):
        objs = list(builder_state.iter_objects())
        if self.paint_bvhtree is None:
            self.paint_bvhtree = utils.get_bvhtree(objs)
            self.paint_ignore.extend(objs)
            self.paint_location = self.location
            self.paint_vector = None
            builder_state.apply_object()
        else:
            paint_vector = self.location - self.paint_location
            paint_rotation = self.paint_rotation
            if self.paint_vector is not None:
                quat = self.paint_vector.rotation_difference(paint_vector)
                self.paint_rotation = self.paint_rotation @ quat

            self.update_object()
            paint_bvhtree = utils.get_bvhtree(objs)
            if len(self.paint_bvhtree.overlap(paint_bvhtree)) > 0:
                self.paint_rotation = paint_rotation
            else:
                self.paint_bvhtree = paint_bvhtree
                self.paint_ignore.extend(objs)
                self.paint_vector = paint_vector
                self.paint_location = self.location

                builder_state.apply_object()

            if not builder_state.is_empty():
                for obj in builder_state.iter_objects():
                    obj.scale = (0, 0, 0)

    def snap(self, x, y):
        settings = bpy.context.scene.level_builder.builder

        objs = list(builder_state.iter_objects())
        objs.extend(self.paint_ignore)
        hit, location, normal = ray_cast.hit(x, y, objs)
        if not hit:
            location = utils.get_viewport_location(x, y, settings.snap_default_distance)
            normal = Vector((0.0, 0.0, 1.0))
            ground_location = None
            if settings.snap_ground:
                ground_location = utils.get_point_in_plane(x, y, Vector((0.0, 0.0, 0.0)), normal)
            if ground_location is not None:
                location = ground_location

        if int(settings.snap_align_target) == 1:
            normal = Vector(settings.snap_align_custom)

        self.location = location
        self.quat = utils.align_rotation(int(settings.snap_align_object), normal)
        self.normal = normal


class PaintBuilder:

    def __init__(self):
        self.key_to_ins = {'WHEELUPMOUSE': 1, 'WHEELDOWNMOUSE': -1}
        self.key_to_dir = {'X': 0, 'Y': 1, 'Z': 2}

        self.gizmo = gizmo.Circle()
        self.gizmo.set_color((1.0, 1.0, 0.0, 0.2))

        self.reset()

    def reset(self):
        self.locations = []
        self.scatter_settings = (-1, -1, None, None)

        self.painting = False
        self.paint_location = None
        self.instancers_matrices = None
        self.stacked_instancers_matrices = None

        self.seed = None
        self.paint_index = 0
        self.seq_index = 0

        self.gizmo.set_radius(0)

    def apply(self, x, y, event):
        pass

    def start(self):
        self.reset()

    def suspend(self, x, y, event):
        pass

    def exit(self):
        self.apply_stacked()

    def draw_gizmo(self):
        self.gizmo.draw()

    def handle_event(self, x, y, event):
        settings = bpy.context.scene.level_builder.builder

        if builder_state.is_empty():
            self.scatter(x, y)

        if event.value == 'PRESS':
            if event.type == 'R':
                self.stacked_instancers_matrices = None
                self.scatter(x, y)

            if event.type == 'RET':
                self.apply_stacked()
                self.scatter(x, y)

            if event.type == 'LEFTMOUSE':
                self.painting = True
                self.paint(x, y)

            if event.type == 'N':
                self.seed += random.randrange(2e16)
                self.scatter_settings = (-1, -1, None, None)
                self.scatter(x, y)

            if event.type in self.key_to_ins.keys():
                ins = self.key_to_ins[event.type]
                if event.shift:
                    settings.paint_density += ins * 10
                else:
                    settings.paint_radius += ins
                self.seq_index = 0
                self.scatter(x, y)
                utils.get_bpy_area('PROPERTIES').tag_redraw()

            if event.type in self.key_to_dir.keys():
                align = self.key_to_dir[event.type]
                if event.shift:
                    align += 3
                settings.paint_align_object = str(align)
                self.scatter(x, y)
                utils.get_bpy_area('PROPERTIES').tag_redraw()

            if event.type == 'S':
                settings.paint_sphere = not settings.paint_sphere
                self.scatter(x, y)
                utils.get_bpy_area('PROPERTIES').tag_redraw()

            if event.type == 'U':
                settings.paint_uniform = not settings.paint_uniform
                self.scatter(x, y)
                utils.get_bpy_area('PROPERTIES').tag_redraw()

        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            self.painting = False
            self.paint_location = None

        if event.type == 'MOUSEMOVE':
            if self.painting:
                self.paint(x, y)
            else:
                self.scatter(x, y)
                self.paint_location = None

    def apply_stacked(self):
        if self.stacked_instancers_matrices is None:
            instancers_matrices = [[] for _ in range(object_pool.get_count())]
        else:
            instancers_matrices = self.stacked_instancers_matrices
        builder_state.update_instancers(instancers_matrices)
        builder_state.apply_object()
        self.stacked_instancers_matrices = None

    def paint(self, x, y):
        settings = bpy.context.scene.level_builder.builder

        length = 0
        interval = settings.paint_interval_scale * settings.paint_radius
        interval = max(interval, settings.paint_interval_min)

        if self.paint_location is None:
            length = interval
        else:
            objs = list(builder_state.iter_instancers())
            hit, location, normal = ray_cast.hit(x, y, objs)
            if hit:
                length = (self.paint_location - location).length

                if int(settings.paint_project_normal) == 1:
                    normal = -Vector(settings.paint_project_custom)
                self.gizmo.set_location(location + normal * 0.3)
                self.gizmo.set_normal(normal)
            self.gizmo.set_radius(0 if not hit else settings.paint_radius)

        if length >= interval:
            self.scatter(x, y)
            self.paint_index += 1
            if self.stacked_instancers_matrices is None:
                self.stacked_instancers_matrices = [item[:] for item in self.instancers_matrices]
            else:
                for item, item_to_add in zip(self.stacked_instancers_matrices, self.instancers_matrices):
                    item.extend(item_to_add)
            self.seq_index += len(self.instancers_matrices)

    def update_locations(self):
        settings = bpy.context.scene.level_builder.builder
        scatter_settings = (settings.paint_radius, settings.paint_density, settings.paint_sphere, settings.paint_uniform)
        if scatter_settings == self.scatter_settings:
            return
        self.scatter_settings = scatter_settings

        with random_state(self.seed) as (seed, a, b, c):
            self.seed = seed
            random.seed(a=a + b * self.paint_index)

            self.locations = []
            for i in range(settings.paint_density):
                r = random.random()
                if settings.paint_sphere:
                    if settings.paint_uniform:
                        r = r**(1 / 3)
                    r *= settings.paint_radius
                    v = Vector((random.random() - 0.5, random.random() - 0.5, random.random() - 0.5))
                    l = r * v.normalized()
                else:
                    if settings.paint_uniform:
                        r = r**(0.5)
                    r *= settings.paint_radius
                    q = Quaternion((0.0, 0.0, 1.0), random.random() * 2 * math.pi)
                    l = q @ (Vector((1.0, 0.0, 0.0)) * r)
                self.locations.append(l)

    def scatter(self, x, y):
        settings = bpy.context.scene.level_builder.builder

        self.update_locations()
        objs = list(builder_state.iter_instancer_objs())
        hit_location, hit_normal, scatters = ray_cast.scatter(x, y, settings.paint_radius, self.locations, objs)
        self.paint_location = hit_location
        if hit_location is not None:
            if int(settings.paint_project_normal) == 1:
                hit_normal = -Vector(settings.paint_project_custom)
            self.gizmo.set_location(hit_location + hit_normal * 0.3)
            self.gizmo.set_normal(hit_normal)
        self.gizmo.set_radius(0 if hit_location is None else settings.paint_radius)

        with random_state(self.seed) as (seed, a, b, c):
            self.seed = seed
            random.seed(a=a + b * self.paint_index - c)

            object_pool.restart_seq_index(self.seq_index)
            indices = object_pool.get_object_indices(len(scatters))
            object_pool.restore_seq_index()

            self.instancers_matrices = [[] for _ in range(object_pool.get_count())]
            for i, (index, (location, normal)) in enumerate(zip(indices, scatters)):
                index %= object_pool.get_count()
                random.seed(a=a + b * self.paint_index + c * i)
                if int(settings.paint_align_target) == 1:
                    normal = Vector(settings.paint_align_custom)
                matrix = object_pool.get_randomness_matrix(index, location, normal, int(settings.paint_align_object))
                if matrix is not None:
                    matrix @= Matrix.Translation(pivot_selector.get_offset(index))
                    self.instancers_matrices[index].append(matrix)

        if self.stacked_instancers_matrices is None:
            instancers_matrices = [item[:] for item in self.instancers_matrices]
        else:
            instancers_matrices = [item[:] for item in self.stacked_instancers_matrices]
            for item, item_to_add in zip(instancers_matrices, self.instancers_matrices):
                item.extend(item_to_add)

        builder_state.update_instancers(instancers_matrices)


class PivotSelector:

    def __init__(self):
        self.key_to_mode = {'WHEELUPMOUSE': -1, 'WHEELDOWNMOUSE': 1}
        self.select_pivot = False
        self.mode = 0
        self.offset = []
        self.selected = []

        self.bounds = []
        self.points = []
        self.colors = []
        self.active = -1
        self.active_color = (1.0, 1.0, 1.0, 1.0)

        self.gizmo_points = gizmo.Points()
        self.gizmo_lines = gizmo.Lines()
        self.gizmo_lines.set_color((1.0, 1.0, 0.0, 0.6))

    def reset(self):
        self.select_pivot = False
        self.offset = [None] * object_pool.get_count()
        self.selected = [(-1, -1)] * object_pool.get_count()

    def valid(self):
        if not builder_state.placing_object():
            return False
        for obj in builder_state.iter_objects():
            if obj.type == 'MESH':
                return True
        return False

    def selecting(self):
        return self.select_pivot

    def draw_gizmo(self):
        if not self.select_pivot or not self.valid():
            return
        self.gizmo_lines.draw()
        self.gizmo_points.draw()

    def handle_event(self, x, y, event):
        if not self.valid():
            return

        if event.value == 'PRESS':
            if event.type in self.key_to_mode.keys():
                mode = self.key_to_mode[event.type]
                self.mode = (self.mode + mode) % 4
                self.active = -1
                self.update_bounds()

        if event.type == 'P':
            if event.value == 'PRESS':
                if event.alt:
                    self.active = -1
                    self.offset[builder_state.get_object_index()] = Vector((0.0, 0.0, 0.0))
                elif event.shift:
                    self.offset = [None] * object_pool.get_count()
                    self.selected = [(self.mode, self.active)] * object_pool.get_count()
                else:
                    self.start()
            elif event.value == 'RELEASE':
                self.select_pivot = False

        if self.select_pivot:
            active = -1
            dist = 1e24
            mouse = Vector((x, y))

            points = (utils.view_3d_to_2d(loc) for loc in self.points)
            for i, point in enumerate(points):
                d = (point - mouse).length
                if d < dist:
                    dist = d
                    active = i

            if self.active != active:
                self.set_active(active)
                self.gizmo_points.set_locations(self.points, self.colors)

    def set_active(self, index):
        if self.active != -1:
            self.colors[self.active] = self.active_color
        self.active = index
        self.active_color = self.colors[index]
        self.colors[index] = (0.2, 0.2, 1.0, 1.0)
        self.offset[builder_state.get_object_index()] = -Vector(self.bounds[index])

    def get_offset(self, index=-1):
        index = builder_state.get_object_index() if index == -1 else index
        if self.offset[index] is None:
            mode, active = self.selected[index]
            if active == -1:
                self.offset[index] = Vector((0.0, 0.0, 0.0))
            else:
                data = object_pool.get_object_datas(index)
                obj, objs = next(utils.iter_parent_children_in(data.cached_objs))
                bounds, _, _ = self.get_bounds(mode, obj, objs)
                self.offset[index] = -Vector(bounds[active])
        return self.offset[index]

    def start(self):
        if self.select_pivot:
            return
        self.select_pivot = True
        self.update_bounds()

    def update_bounds(self):
        obj = builder_state.get_object()
        objs = builder_state.iter_objects()
        self.bounds, self.points, self.colors = self.get_bounds(self.mode, obj, objs)

        self.gizmo_points.set_locations(self.points, self.colors)
        self.gizmo_lines.set_vertices(self.points[0:8])

    def get_bounds(self, mode, obj, objs):
        v_min = Vector((1e24, 1e24, 1e24))
        v_max = Vector((-1e24, -1e24, -1e24))

        matrix = obj.matrix_world.inverted_safe()
        for obj in objs:
            bb = [matrix @ obj.matrix_world @ Vector((v[0], v[1], v[2])) for v in obj.bound_box]
            if mode < 2:
                bb.append(matrix @ obj.matrix_world @ Vector((0.0, 0.0, 0.0)))
            x = [v.x for v in bb]
            y = [v.y for v in bb]
            z = [v.z for v in bb]
            v1 = Vector((min(*x), min(*y), min(*z)))
            v2 = Vector((max(*x), max(*y), max(*z)))

            for i in range(3):
                v_min[i] = v1[i] if v1[i] < v_min[i] else v_min[i]
                v_max[i] = v2[i] if v2[i] > v_max[i] else v_max[i]

        color1 = (1.0, 1.0, 1.0, 1.0)
        color2 = (1.0, 1.0, 0.5, 1.0)
        color3 = (1.0, 0.5, 0.5, 1.0)
        color4 = (1.0, 0.5, 1.0, 1.0)
        if mode % 2 == 0:
            center = (v_min + v_max) * 0.5
            bounds = ((v_min.x, v_min.y, v_min.z), (v_min.x, v_max.y, v_min.z), (v_max.x, v_min.y, v_min.z), (v_max.x, v_max.y, v_min.z),
                      (v_min.x, v_min.y, v_max.z), (v_min.x, v_max.y, v_max.z), (v_max.x, v_min.y, v_max.z), (v_max.x, v_max.y, v_max.z),

                      (center.x, v_min.y, v_min.z), (center.x, v_max.y, v_min.z), (center.x, v_min.y, v_max.z), (center.x, v_max.y, v_max.z),
                      (v_min.x, center.y, v_min.z), (v_max.x, center.y, v_min.z), (v_min.x, center.y, v_max.z), (v_max.x, center.y, v_max.z),
                      (v_min.x, v_min.y, center.z), (v_max.x, v_min.y, center.z), (v_min.x, v_max.y, center.z), (v_max.x, v_max.y, center.z),

                      (center.x, center.y, v_min.z), (center.x, center.y, v_max.z),
                      (center.x, v_min.y, center.z), (center.x, v_max.y, center.z),
                      (v_min.x, center.y, center.z), (v_max.x, center.y, center.z),
                      (center.x, center.y, center.z))

            colors = [color1, color1, color1, color1, color1, color1, color1, color1,
                      color2, color2, color2, color2, color2, color2, color2, color2, color2, color2, color2, color2,
                      color3, color3, color3, color3, color3, color3,
                      color4]
        else:
            center = Vector((0.0, 0.0, 0.0))
            center.x = sorted((v_min.x, 0, v_max.x))[1]
            center.y = sorted((v_min.y, 0, v_max.y))[1]
            center.z = sorted((v_min.z, 0, v_max.z))[1]
            bounds = ((v_min.x, v_min.y, v_min.z), (v_min.x, v_max.y, v_min.z), (v_max.x, v_min.y, v_min.z), (v_max.x, v_max.y, v_min.z),
                      (v_min.x, v_min.y, v_max.z), (v_min.x, v_max.y, v_max.z), (v_max.x, v_min.y, v_max.z), (v_max.x, v_max.y, v_max.z),

                      (center.x, v_min.y, v_min.z), (center.x, v_max.y, v_min.z), (center.x, v_min.y, v_max.z), (center.x, v_max.y, v_max.z),
                      (v_min.x, center.y, v_min.z), (v_max.x, center.y, v_min.z), (v_min.x, center.y, v_max.z), (v_max.x, center.y, v_max.z),
                      (v_min.x, v_min.y, center.z), (v_max.x, v_min.y, center.z), (v_min.x, v_max.y, center.z), (v_max.x, v_max.y, center.z),

                      (center.x, center.y, v_min.z), (center.x, center.y, v_max.z),
                      (center.x, v_min.y, center.z), (center.x, v_max.y, center.z),
                      (v_min.x, center.y, center.z), (v_max.x, center.y, center.z))

            colors = [color1, color1, color1, color1, color1, color1, color1, color1,
                      color2, color2, color2, color2, color2, color2, color2, color2, color2, color2, color2, color2,
                      color3, color3, color3, color3, color3, color3]

        matrix = obj.matrix_world
        points = [matrix @ Vector(v) for v in bounds]

        return bounds, points, colors

builder_state = BuilderState()
builder_ui = BuilderUI()
builder = Builder()
pivot_selector = PivotSelector()

start = builder.start
close = builder.close
suspend = builder.suspend
draw = builder.draw
draw_gizmo = builder.draw_gizmo
handle_event = builder.handle_event
set_size = builder_ui.set_size


@contextmanager
def random_state(seed):
    rs = random.getstate()
    if seed is None:
        seed = random.randrange(2**31)
    random.seed(a=seed)
    a = random.randrange(2**30)
    b = random.randrange(2**15)
    c = random.randrange(2**7)
    yield seed, a, b, c
    random.setstate(rs)
