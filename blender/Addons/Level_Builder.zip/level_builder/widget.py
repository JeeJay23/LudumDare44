import bgl
import blf
import gpu
from gpu_extras.batch import batch_for_shader


class Base:

    def __init__(self, x=0, y=0, width=0, height=0):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.parent = None
        self.children = []
        self.root_height = height
        self.clip = False
        self.scrollable = False
        self.scroll_y = 0
        self.mouse_down_func = None
        self.mouse_down_param = None
        self.set_dirty()

    def set_position(self, x, y):
        if self.x != x or self.y != y:
            self.set_dirty()
        self.x = x
        self.y = y

    def set_size(self, width, height):
        update = self.width != width or self.height != height
        self.width = width
        self.height = height
        if update:
            self.set_dirty()
            if self.parent is None:
                self.set_root_height(height)

    def set_root_height(self, height):
        self.root_height = height
        for child in self.children:
            child.set_root_height(height)

    def set_clip(self, clip):
        self.clip = clip

    def add(self, child):
        if child not in self.children:
            self.children.append(child)
            child.parent = self
            child.root_height = self.root_height
            child.set_dirty()

    def remove(self, child):
        self.children.remove(child)
        child.parent = None

    def remove_all(self):
        for child in self.children[:]:
            self.remove(child)

    def move(self, x, y):
        self.x += x
        self.y += y
        self.set_dirty()

    def set_dirty(self):
        self.dirty = True
        self.on_change()
        for child in self.children:
            child.set_dirty()

    def on_change(self):
        pass

    def draw(self, x=0, y=0):
        x += self.x
        y += self.y
        y2 = self.root_height - y - self.height

        if self.clip:
            bgl.glScissor(x, y2, self.width, self.height)
            bgl.glEnable(bgl.GL_SCISSOR_TEST)

        if self.dirty:
            self.dirty = False
            self.update(x, y2)
        self.draw_widget(x, y2)

        for child in self.children:
            child.draw(x, y - self.scroll_y)

        if self.clip:
            bgl.glDisable(bgl.GL_SCISSOR_TEST)

    def update(self, x, y):
        pass

    def draw_widget(self, x, y):
        pass

    def handle_event(self, x, y, event):
        if self.parent is None:
            y = self.height - y

        offset = self.parent is not None
        x -= 0 if not offset else self.parent.x
        y -= 0 if not offset else self.parent.y

        if not self.clip or self.is_inside(x, y):
            for child in self.children:
                if child.handle_event(x, y + self.scroll_y, event):
                    return True

        if event.type == 'LEFTMOUSE':
            if event.value == 'PRESS':
                return self.mouse_down(x, y, event)
            else:
                return self.mouse_up(x, y, event)
        elif event.type == 'MOUSEMOVE':
            return self.mouse_move(x, y, event)
        elif event.type == 'WHEELUPMOUSE':
            return self.mouse_wheel(x, y, -1, event)
        elif event.type == 'WHEELDOWNMOUSE':
            return self.mouse_wheel(x, y, 1, event)

        return False

    def is_inside(self, x, y):
        return ((self.x <= x < (self.x + self.width)) and
                (self.y <= y < (self.y + self.height)))

    def set_mouse_down(self, func, param):
        self.mouse_down_func = func
        self.mouse_down_param = param

    def mouse_down(self, x, y, event):
        if self.is_inside(x, y) and self.mouse_down_func is not None:
            return self.mouse_down_func(self, event, self.mouse_down_param)
        return False

    def mouse_move(self, x, y, event):
        return False

    def mouse_up(self, x, y, event):
        return False

    def mouse_wheel(self, x, y, v, event):
        if self.scrollable and self.is_inside(x, y):
            self.scroll_y += v * (240 if event.shift else 80)
            h = max([child.y + child.height for child in self.children]) - self.height
            h = 0 if h < 0 else h
            self.scroll_y = sorted((0, self.scroll_y, h))[1]
            self.set_dirty()
            return True
        return False


class Draggable(Base):

    def __init__(self, x=0, y=0, width=0, height=0):
        self.is_drag = False
        super().__init__(x, y, width, height)

    def mouse_down(self, x, y):
        if self.is_inside(x, y):
            self.is_drag = True
            self.drag_x = x
            self.drag_y = y
            return True

        return False

    def mouse_move(self, x, y):
        if self.is_drag:
            self.move(x - self.drag_x, y - self.drag_y)
            self.drag_x = x
            self.drag_y = y
            return True

        return False

    def mouse_up(self, x, y):
        drag = self.is_drag
        self.is_drag = False
        return drag


class Highlightable(Base):

    def __init__(self, x=0, y=0, width=0, height=0):
        self.hover = False
        self.raw_color = self.color
        self.highlight = None
        super().__init__(x, y, width, height)

    def set_color(self, color):
        self.raw_color = color
        self.update_color()

    def set_highlight(self, color):
        self.highlight = color
        self.update_color()

    def update_color(self):
        self.color = self.raw_color if not self.hover or self.highlight is None else self.highlight

    def mouse_move(self, x, y, event):
        self.hover = self.is_inside(x, y)
        self.update_color()


class Rect(Highlightable):

    def __init__(self, x=0, y=0, width=0, height=0):
        self.color = (0.8, 0.8, 0.8, 0.8)
        self.shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
        self.indices = ((0, 1, 2), (0, 2, 3))
        self.vertices = ((0.0, 0.0), (0.0, 1.0), (1.0, 1.0), (1.0, 0.0))
        super().__init__(x, y, width, height)

    def set_shape(self, indices, vertices):
        self.indices = indices
        self.vertices = vertices
        self.set_dirty()

    def update(self, x, y):
        vertices = [(x + vx * self.width, y + vy * self.height) for (vx, vy) in self.vertices]
        self.batch = batch_for_shader(self.shader, 'TRIS', {"pos": vertices}, indices=self.indices)

    def draw_widget(self, x, y):
        self.shader.bind()
        self.shader.uniform_float("color", self.color)

        bgl.glEnable(bgl.GL_BLEND)
        self.batch.draw(self.shader)
        bgl.glDisable(bgl.GL_BLEND)


class Frame(Highlightable):

    def __init__(self, x=0, y=0, width=0, height=0):
        self.color = (0.8, 0.8, 0.8, 0.8)
        self.line_width = 1
        self.shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
        self.indices = ((0, 1), (1, 2), (2, 3), (3, 0))
        self.vertices = ((0.0, 0.0), (0.0, 1.0), (1.0, 1.0), (1.0, 0.0))
        super().__init__(x, y, width, height)

    def set_frame_width(self, width):
        self.line_width = width

    def set_shape(self, indices, vertices):
        self.indices = indices
        self.vertices = vertices
        self.set_dirty()

    def update(self, x, y):
        vertices = [(x + vx * self.width, y + vy * self.height) for (vx, vy) in self.vertices]
        self.batch = batch_for_shader(self.shader, 'LINES', {"pos": vertices}, indices=self.indices)

    def draw_widget(self, x, y):
        self.shader.bind()
        self.shader.uniform_float("color", self.color)

        bgl.glLineWidth(self.line_width)
        bgl.glEnable(bgl.GL_BLEND)
        bgl.glEnable(bgl.GL_LINE_SMOOTH)
        self.batch.draw(self.shader)
        bgl.glDisable(bgl.GL_BLEND)
        bgl.glDisable(bgl.GL_LINE_SMOOTH)


class Text(Highlightable):

    def __init__(self, x=0, y=0, width=0, height=0):
        self.text = "Text"
        self.text_size = 16
        self.color = (0.2, 0.2, 0.2, 1.0)
        super().__init__(x, y, width, height)

    def set_text(self, text):
        self.text = text

    def set_text_size(self, size):
        self.text_size = size

    def get_widget_size(self):
        blf.size(0, self.text_size, 72)
        size = blf.dimensions(0, self.text)
        return size

    def draw_widget(self, x, y):
        blf.size(0, self.text_size, 72)
        blf.color(0, *self.color)
        size = blf.dimensions(0, self.text)
        blf.position(0, x + (self.width - size[0]) / 2.0, y + (self.height - size[1]) / 2.0, 0)
        blf.clipping(0, x, y, x + self.width, y + self.height)
        blf.enable(0, blf.CLIPPING)
        blf.draw(0, self.text)
        blf.disable(0, blf.CLIPPING)


class Image(Base):

    def __init__(self, x=0, y=0, width=0, height=0):
        self.image = None
        self.shader = gpu.shader.from_builtin('2D_IMAGE')
        super().__init__(x, y, width, height)

    def set_image(self, image):
        self.image = image

    def update(self, x, y):
        indices = ((0, 1, 2), (0, 2, 3))
        texcoord = ((0, 0), (0, 1), (1, 1), (1, 0))
        vertices = ((x, y), (x, y + self.height), (x + self.width, y + self.height), (x + self.width, y))
        self.batch = batch_for_shader(self.shader, 'TRIS', {"pos": vertices, "texCoord": texcoord}, indices=indices)

    def draw_widget(self, x, y):
        if self.image is None or self.image.gl_load() != 0:
            return

        bgl.glActiveTexture(bgl.GL_TEXTURE0)
        bgl.glBindTexture(bgl.GL_TEXTURE_2D, self.image.bindcode)

        self.shader.bind()
        self.shader.uniform_int("image", 0)

        bgl.glEnable(bgl.GL_BLEND)
        self.batch.draw(self.shader)
        bgl.glDisable(bgl.GL_BLEND)
