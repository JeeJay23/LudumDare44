import re
import bpy


class LB_ReplaceMaterialsSettings(bpy.types.PropertyGroup):

    material: bpy.props.PointerProperty(name="Material", type=bpy.types.Material)
    pattern: bpy.props.StringProperty(name="Pattern", default="Pattern")


class LB_ReplaceMaterialsPanel(bpy.types.Panel):

    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_label = "Replace Materials"
    bl_category = "Level Builder"
    bl_context = 'objectmode'

    def draw(self, context):
        layout = self.layout
        settings = context.scene.lb_replace_materials

        column = layout.column()
        column.prop(settings, "material", text="")
        column.prop(settings, "pattern", text="")
        column.operator(LB_ReplaceMaterials.bl_idname, icon='UV_SYNC_SELECT')


class LB_ReplaceMaterials(bpy.types.Operator):

    bl_idname = "lb.replace_materials"
    bl_label = "Replace Materials"
    bl_description = "Replace materials with pattern"

    def execute(self, context):
        material = context.scene.lb_replace_materials.material
        pattern = context.scene.lb_replace_materials.pattern

        for obj in bpy.context.scene.objects:
            for slot in obj.material_slots:
                mat = slot.material
                if mat == material:
                    continue
                if re.search(pattern, mat.name) is not None:
                    slot.material = material
        return {'FINISHED'}

classes = (
    LB_ReplaceMaterialsSettings,
    LB_ReplaceMaterials,
    LB_ReplaceMaterialsPanel
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.lb_replace_materials = bpy.props.PointerProperty(type=LB_ReplaceMaterialsSettings)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.lb_replace_materials
