import math
import bpy
from bpy_extras.io_utils import ImportHelper
from . import selector
from . import utils
from . import object_pool


class LB_SelectorLibraryItem(bpy.types.PropertyGroup):

    lib_file: bpy.props.StringProperty(name="Library", subtype='FILE_PATH')
    enable: bpy.props.BoolProperty(name="Enable")
    selected_collection: bpy.props.StringProperty(name="Selected Collection", default="")


class LB_SelectorSettings(bpy.types.PropertyGroup):

    open_selector: bpy.props.BoolProperty(name="Selector")
    libraries: bpy.props.CollectionProperty(name="Libraries", type=LB_SelectorLibraryItem)
    item_size: bpy.props.IntProperty(name="Item Size", default=128)
    selected_library: bpy.props.IntProperty(name="Selected Library", default=-1)
    flatten_collection: bpy.props.BoolProperty(name="Flatten Collection", default=True)


class LB_SelectorLibraryList(bpy.types.UIList):

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        self.use_filter_show = False
        name = bpy.path.display_name_from_filepath(item.lib_file)
        row = layout.row(align=True)
        row.prop(item, "enable", text="")
        row.label(text=name)


class LB_SelectorPanel(bpy.types.Panel):

    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_label = "Asset Libraries"
    bl_category = "Level Builder"
    bl_context = 'objectmode'

    def draw(self, context):
        layout = self.layout
        settings = context.scene.level_builder.selector

        column = layout.column(align=True)
        if settings.open_selector:
            column.prop(settings, "open_selector", toggle=True, icon='ASSET_MANAGER')
        else:
            column.operator(selector.LB_Selector.bl_idname, icon='ASSET_MANAGER')
        column.prop(settings, "flatten_collection")

        column = layout.column(align=True)
        column.template_list("LB_SelectorLibraryList", "", settings, "libraries", settings, "selected_library", type='DEFAULT')
        row = column.row(align=True)
        row.alignment = 'RIGHT'
        row.operator(LB_SelectorAddLibrary.bl_idname, icon='ADD', text="")
        row.operator(LB_SelectorRemoveLibrary.bl_idname, icon='REMOVE', text="")
        row.operator(LB_SelectorMoveUpLibrary.bl_idname, icon='SORT_DESC', text="")
        row.operator(LB_SelectorMoveDownLibrary.bl_idname, icon='SORT_ASC', text="")


class LB_SelectorAddLibrary(bpy.types.Operator, ImportHelper):

    bl_idname = "lb.add_library"
    bl_label = "Add"
    bl_description = "Add Library"
    bl_options = set()

    filter_glob: bpy.props.StringProperty(default="*.blend", options={'HIDDEN'})

    def execute(self, context):
        settings = context.scene.level_builder.selector
        item = settings.libraries.add()
        item.lib_file = self.properties.filepath
        item.enable = True
        return {'FINISHED'}


class LB_SelectorRemoveLibrary(bpy.types.Operator):

    bl_idname = "lb.remove_library"
    bl_label = "Remove"
    bl_description = "Remove Library"
    bl_options = set()

    @classmethod
    def poll(cls, context):
        return context.scene.level_builder.selector.selected_library >= 0

    def execute(self, context):
        settings = context.scene.level_builder.selector
        settings.libraries.remove(settings.selected_library)
        if len(settings.libraries) == 0:
            settings.selected_library = -1
        elif settings.selected_library >= len(settings.libraries):
            settings.selected_library -= 1
        return {'FINISHED'}


class LB_SelectorMoveUpLibrary(bpy.types.Operator):

    bl_idname = "lb.move_up_library"
    bl_label = "Move Up"
    bl_description = "Move Up Library"
    bl_options = set()

    def execute(self, context):
        settings = context.scene.level_builder.selector
        if settings.selected_library > 0:
            settings.libraries.move(settings.selected_library, settings.selected_library - 1)
            settings.selected_library -= 1
        return {'FINISHED'}


class LB_SelectorMoveDownLibrary(bpy.types.Operator):

    bl_idname = "lb.move_down_library"
    bl_label = "Move Down"
    bl_description = "Move Down Library"
    bl_options = set()

    def execute(self, context):
        settings = context.scene.level_builder.selector
        if settings.selected_library < len(settings.libraries) - 1:
            settings.libraries.move(settings.selected_library, settings.selected_library + 1)
            settings.selected_library += 1
        return {'FINISHED'}


class LB_BuilderSettings(bpy.types.PropertyGroup):

    mode: bpy.props.EnumProperty(name="Mode", items=[("0", "Grid", "", "VIEW_ORTHO", 0),
                                                     ("1", "Surface", "", "ORIENTATION_NORMAL", 1),
                                                     ("2", "Scatter", "", "GREASEPENCIL", 2)])

    grid_mode: bpy.props.EnumProperty(name="Grid Mode", items=[("-1", "None", "", "HIDE_ON", -1),
                                                               ("0", "Grid", "", "VIEW_ORTHO", 0),
                                                               ("1", "Checker", "", "NODE_TEXTURE", 1)])
    grid_size: bpy.props.FloatVectorProperty(name="Grid Size", default=(1.0, 1.0, 1.0), step=100, min=0.1, soft_min=1, subtype='XYZ')
    grid_step: bpy.props.FloatProperty(name="Grid Step", default=1.0)
    grid_rotate: bpy.props.FloatProperty(name="Rotate Step", default=math.pi / 4, step=100, unit='ROTATION')
    grid_scale: bpy.props.FloatProperty(name="Scale Step", default=0.5, step=10)
    grid_color1: bpy.props.FloatVectorProperty(name="Grid Color 1", size=4, default=(0.8, 0.8, 0.8, 0.4), subtype='COLOR')
    grid_color2: bpy.props.FloatVectorProperty(name="Grid Color 2", size=4, default=(0.2, 0.2, 0.2, 0.4), subtype='COLOR')
    grid_offset: bpy.props.BoolProperty(name="Center Offset", description="Add half size offset to the grid.")
    grid_location: bpy.props.FloatVectorProperty(name="Grid Location", subtype='XYZ')
    grid_direction: bpy.props.EnumProperty(name="Grid Direction", items=[("0", "X", "", "AXIS_SIDE", 0),
                                                                         ("1", "Y", "", "AXIS_FRONT", 1),
                                                                         ("2", "Z", "", "AXIS_TOP", 2)], default='2')

    snap_align_object: bpy.props.EnumProperty(name="Align Object", items=[("0", "X", ""), ("1", "Y", ""), ("2", "Z", ""),
                                                                          ("3", "-X", ""), ("4", "-Y", ""), ("5", "-Z", "")], default='2')
    snap_align_target: bpy.props.EnumProperty(name="Align Target", items=[("0", "Surface", "", "ORIENTATION_NORMAL", 0),
                                                                          ("1", "Custom", "", "EMPTY_SINGLE_ARROW", 1)])
    snap_align_custom: bpy.props.FloatVectorProperty(name="Align Custom", default=(0.0, 0.0, 1.0), subtype='XYZ')
    snap_offset: bpy.props.FloatProperty(name="Offset Step", default=0.01, step=1)
    snap_rotate: bpy.props.FloatProperty(name="Rotate Step", default=math.pi / 4, step=100, unit='ROTATION')
    snap_scale: bpy.props.FloatProperty(name="Scale Step", default=0.5, step=10)
    snap_ground: bpy.props.BoolProperty(name="Snap Ground", description="Snap to ground if no surface detected.", default=True)
    snap_default_distance: bpy.props.FloatProperty(name="Distance", description="The distance to viewport used to place object.", default=10.0, step=10)
    snap_stroke_direction: bpy.props.BoolProperty(name="Stroke Direction", description="Paint along stroke direction.", default=True)

    paint_radius: bpy.props.FloatProperty(name="Radius", default=5.0, step=100, min=0.0)
    paint_density: bpy.props.IntProperty(name="Density", default=10, step=1, min=1)
    paint_interval_scale: bpy.props.FloatProperty(name="Interval Scale", default=0.5, step=10, min=0.1)
    paint_interval_min: bpy.props.FloatProperty(name="Interval Min", default=1.0, step=10, min=0.1)
    paint_sphere: bpy.props.BoolProperty(name="Sphere")
    paint_uniform: bpy.props.BoolProperty(name="Uniform")
    paint_mode: bpy.props.EnumProperty(name="Mode", items=[("0", "Project", "", "SNAP_NORMAL", 0),
                                                           ("1", "Nearest", "", "PARTICLE_POINT", 1)])
    paint_no_discard_missed: bpy.props.BoolProperty(name="Use nearest on projection missed")
    paint_project_normal: bpy.props.EnumProperty(name="Project Normal", items=[("0", "Surface", "", "ORIENTATION_NORMAL", 0),
                                                                               ("1", "Custom", "", "EMPTY_SINGLE_ARROW", 1)])
    paint_project_custom: bpy.props.FloatVectorProperty(name="Project Custom", default=(0.0, 0.0, -1.0), subtype='XYZ')
    paint_align_object: bpy.props.EnumProperty(name="Align Object", items=[("0", "X", ""), ("1", "Y", ""), ("2", "Z", ""),
                                                                           ("3", "-X", ""), ("4", "-Y", ""), ("5", "-Z", "")], default='2')
    paint_align_target: bpy.props.EnumProperty(name="Align Target", items=[("0", "Surface", "", "ORIENTATION_NORMAL", 0),
                                                                           ("1", "Custom", "", "EMPTY_SINGLE_ARROW", 1)])
    paint_align_custom: bpy.props.FloatVectorProperty(name="Align Custom", default=(0.0, 0.0, 1.0), subtype='XYZ')


class LB_BuilderPanel(bpy.types.Panel):

    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_label = "Level Builder"
    bl_context = '.objectmode'
    bl_ui_units_x = 20

    def draw(self, context):
        layout = self.layout
        settings = context.scene.level_builder.builder
        layout.row().prop(settings, "mode", expand=True)
        row = layout.row(align=True)


class LB_BuildModePanel(bpy.types.Panel):

    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_label = "Settings"
    bl_parent_id = "LB_BuilderPanel"
    bl_context = '.objectmode'

    def draw(self, context):
        layout = self.layout
        settings = context.scene.level_builder.builder
        if settings.mode == '0':
            draw_grid_builder_layout(layout, settings)
        elif settings.mode == '1':
            draw_snap_surface_builder_layout(layout, settings)
        elif settings.mode == '2':
            draw_paint_builder_layout(layout, settings)


def draw_grid_builder_layout(layout, settings):
    layout.row().prop(settings, "grid_mode", expand=True)

    column = layout.column(align=True)
    column.label(text="Grid Settings:")
    column.row().prop(settings, "grid_size", text="")
    column.prop(settings, "grid_step")
    column.prop(settings, "grid_rotate")
    column.prop(settings, "grid_scale")
    column.prop(settings, "grid_offset", text="Center Offset", icon='SNAP_GRID', toggle=True)
    row = column.row()
    row.prop(settings, "grid_color1", text="")
    row.prop(settings, "grid_color2", text="")
    column.separator()

    column.label(text="Grid Location:")
    column.row().prop(settings, "grid_location", text="")
    column.row().prop(settings, "grid_direction", expand=True)


def draw_snap_surface_builder_layout(layout, settings):
    column = layout.column(align=True)
    column.label(text="Align Object:")
    column.row().prop(settings, "snap_align_object", expand=True)
    column.row().prop(settings, "snap_align_target", expand=True)
    if int(settings.snap_align_target) == 1:
        column.row().prop(settings, "snap_align_custom", text="")
    column.prop(settings, "snap_stroke_direction", text="Paint along stroke direction")

    column = layout.column(align=True)
    column.prop(settings, "snap_offset")
    column.prop(settings, "snap_rotate")
    column.prop(settings, "snap_scale")
    column.separator()

    column.label(text="No surface:")
    column.prop(settings, "snap_ground", icon='VIEW_PERSPECTIVE', toggle=True)
    column.prop(settings, "snap_default_distance")
    column.separator()


def draw_paint_builder_layout(layout, settings):
    column = layout.column(align=True)
    row = column.row(align=True)
    row.prop(settings, "paint_radius")
    row.prop(settings, "paint_density")
    row = column.row(align=True)
    row.prop(settings, "paint_interval_scale")
    row.prop(settings, "paint_interval_min")
    row = column.row(align=True)
    row.prop(settings, "paint_sphere", toggle=True)
    row.prop(settings, "paint_uniform", toggle=True)
    column.separator()

    column.row().prop(settings, "paint_mode", expand=True)
    if int(settings.paint_mode) == 0:
        column.prop(settings, "paint_no_discard_missed")
    column.label(text="Project Normal:")
    column.row().prop(settings, "paint_project_normal", expand=True)
    if int(settings.paint_project_normal) == 1:
        column.row().prop(settings, "paint_project_custom", text="")
    column.separator()

    column.label(text="Align Object:")
    column.row().prop(settings, "paint_align_object", expand=True)
    column.row().prop(settings, "paint_align_target", expand=True)
    if int(settings.paint_align_target) == 1:
        column.row().prop(settings, "paint_align_custom", text="")


class LB_Randomness(bpy.types.PropertyGroup):

    use_random: bpy.props.BoolProperty(name="Use Random", default=True)
    offset_min: bpy.props.FloatVectorProperty(name="Offset Min", default=(0.0, 0.0, 0.0), step=10.0, subtype='XYZ')
    offset_max: bpy.props.FloatVectorProperty(name="Offset Max", default=(0.5, 0.5, 0.1), step=10.0, subtype='XYZ')
    offset_step: bpy.props.FloatProperty(name="Offset Step", default=0.01, step=1.0, min=0.0)
    rotate_min: bpy.props.FloatProperty(name="Rotate Min", default=0.0, step=100.0, unit='ROTATION')
    rotate_max: bpy.props.FloatProperty(name="Rotate Max", default=math.pi * 2, step=100.0, unit='ROTATION')
    rotate_step: bpy.props.FloatProperty(name="Rotate Step", default=math.pi / 180.0, step=100.0, min=0.0, unit='ROTATION')
    rotate_normal: bpy.props.BoolProperty(name="Rotate Along Normal", default=True)
    scale_min: bpy.props.FloatProperty(name="Scale Min", default=0.5, step=10.0)
    scale_max: bpy.props.FloatProperty(name="Scale Max", default=1.5, step=10.0)
    scale_step: bpy.props.FloatProperty(name="Scale Step", default=0.1, step=10.0, min=0.0)
    scale_uniform: bpy.props.BoolProperty(name="Uniform Scale", default=True)


class LB_ObjectPoolItem(bpy.types.PropertyGroup):

    lib_file: bpy.props.StringProperty(name="Library", subtype='FILE_PATH')
    object_name: bpy.props.StringProperty(name="Object")
    weight: bpy.props.FloatProperty(name="Weight", default=1.0, step=10, min=0.0, max=1.0)
    override: bpy.props.BoolProperty(name="Override Randomness", default=False)
    randomness: bpy.props.PointerProperty(name="Randomness", type=LB_Randomness)


class LB_ObjectPool(bpy.types.PropertyGroup):

    objects: bpy.props.CollectionProperty(name="Pool", type=LB_ObjectPoolItem)
    random: bpy.props.BoolProperty(name="Select Object Randomly", default=True)
    order: bpy.props.StringProperty(name="Order", default="")

    grid_mode_randomness: bpy.props.PointerProperty(name="Randomness (Grid)", type=LB_Randomness)
    snap_mode_randomness: bpy.props.PointerProperty(name="Randomness (Snap Surface)", type=LB_Randomness)
    paint_mode_randomness: bpy.props.PointerProperty(name="Randomness (Paint)", type=LB_Randomness)


class LB_RandomnessPanel(bpy.types.Panel):

    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_label = "Randomness"
    bl_parent_id = "LB_BuilderPanel"
    bl_context = '.objectmode'

    def draw_header(self, context):
        object_pool = context.scene.level_builder.object_pool
        settings = context.scene.level_builder.builder
        randomness = (object_pool.grid_mode_randomness, object_pool.snap_mode_randomness, object_pool.paint_mode_randomness)
        randomness = randomness[int(settings.mode)]
        self.layout.prop(randomness, "use_random", text="")

    def draw(self, context):
        object_pool = context.scene.level_builder.object_pool
        settings = context.scene.level_builder.builder
        randomness = (object_pool.grid_mode_randomness, object_pool.snap_mode_randomness, object_pool.paint_mode_randomness)
        randomness = randomness[int(settings.mode)]
        draw_randomness_layout(self.layout, randomness)


class LB_ObjectPoolPanel(bpy.types.Panel):

    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_label = "Object Pool"
    bl_context = '.objectmode'
    bl_ui_units_x = 20

    def draw(self, context):
        layout = self.layout
        pool = context.scene.level_builder.object_pool

        if len(pool.objects) == 0:
            layout.label(text="No Object Selected.")
            return

        layout.prop(pool, "random")
        layout.prop(pool, "order")
        grid = layout.grid_flow(row_major=True)

        for i, item in enumerate(pool.objects):
            icon = object_pool.get_preview(item.lib_file, item.object_name)
            column = grid.column(align=True)
            if icon is not None:
                column.template_icon(icon.icon_id, scale=3)
            row = column.row(align=True)
            row.scale_x = 0.6
            row2 = row.row(align=True)
            row2.prop(item, "weight", slider=True, text="")
            if len(pool.objects) > 1:
                row2.operator(LB_ObjectPoolItemPopover.bl_idname, icon='THREE_DOTS', text="").index = i

        if len(pool.objects) == 1:
            item = pool.objects[0]
            layout.prop(item, "override")
            if item.override:
                layout.prop(item.randomness, "use_random")
                draw_randomness_layout(layout, item.randomness)


class LB_ObjectPoolItemPopover(bpy.types.Operator):

    bl_idname = "lb.object_pool_item_popover"
    bl_label = "Object Randomness"
    bl_description = "Object Pool Randomness Settings"

    index: bpy.props.IntProperty(name="Index")

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        item = context.scene.level_builder.object_pool.objects[self.index]

        layout.prop(item, "override")
        if item.override:
            layout.prop(item.randomness, "use_random")
            draw_randomness_layout(layout, item.randomness)


def draw_randomness_layout(layout, randomness):
    layout = layout.column()
    layout.active = randomness.use_random

    row = layout.row()
    column = row.column(align=True)
    column.prop(randomness, "offset_min", text="Offset Min")
    column.separator()
    column.prop(randomness, "offset_step")
    column = row.column(align=True)
    column.prop(randomness, "offset_max", text="Max")

    row = layout.row()
    column = row.column(align=True)
    column.label(text="Rotate:")
    column.prop(randomness, "rotate_min", text="Min")
    column.prop(randomness, "rotate_max", text="Max")
    column.prop(randomness, "rotate_step", text="Step")
    column.prop(randomness, "rotate_normal", toggle=True)

    column = row.column(align=True)
    column.label(text="Scale:")
    column.prop(randomness, "scale_min", text="Min")
    column.prop(randomness, "scale_max", text="Max")
    column.prop(randomness, "scale_step", text="Step")


class LB_LevelBuilderSettings(bpy.types.PropertyGroup):

    selector: bpy.props.PointerProperty(type=LB_SelectorSettings)
    builder: bpy.props.PointerProperty(type=LB_BuilderSettings)
    object_pool: bpy.props.PointerProperty(type=LB_ObjectPool)

classes = (
    LB_SelectorLibraryItem,
    LB_SelectorLibraryList,
    LB_Randomness,
    LB_ObjectPoolItem,

    LB_SelectorSettings,
    LB_BuilderSettings,
    LB_ObjectPool,
    LB_LevelBuilderSettings,

    LB_SelectorPanel,
    LB_BuilderPanel,
    LB_BuildModePanel,
    LB_RandomnessPanel,
    LB_ObjectPoolPanel,

    LB_SelectorAddLibrary,
    LB_SelectorRemoveLibrary,
    LB_SelectorMoveUpLibrary,
    LB_SelectorMoveDownLibrary,
    LB_ObjectPoolItemPopover
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.level_builder = bpy.props.PointerProperty(type=LB_LevelBuilderSettings)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)

    del bpy.types.Scene.level_builder
