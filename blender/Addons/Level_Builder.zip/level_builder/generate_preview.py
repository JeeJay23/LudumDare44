import os
import bpy
from math import radians
from mathutils import Vector, Euler

from . import utils


class LB_GeneratePreviewSettings(bpy.types.PropertyGroup):

    format: bpy.props.EnumProperty(name="Format", items=[("PNG", "PNG", ""), ("JPEG", "JPG", "")])
    size: bpy.props.IntVectorProperty(name="Size", default=(128, 128), size=2, subtype='XYZ')
    scene_world: bpy.props.BoolProperty(name="Use Scene World", default=False)
    alpha: bpy.props.BoolProperty(name="Use Alpha", default=True)


class LB_GeneratePreviewPanel(bpy.types.Panel):

    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_label = "Generate Preview"
    bl_category = "Level Builder"
    bl_context = 'objectmode'

    def draw(self, context):
        layout = self.layout
        settings = context.scene.lb_generate_preview

        column = layout.column(align=True)
        column.row().prop(settings, "format", expand=True)
        column.prop(settings, "size")
        column.prop(settings, "scene_world")
        column.prop(settings, "alpha")
        column.operator(LB_GeneratePreview.bl_idname, icon='RENDER_RESULT')


class LB_GeneratePreview(bpy.types.Operator):

    bl_idname = "lb.generate_preview"
    bl_label = "Generate"
    bl_description = "Generate Preview"

    def execute(self, context):
        settings = context.scene.lb_generate_preview

        scene = bpy.context.scene
        scene_camera = scene.camera
        resolution_x = scene.render.resolution_x
        resolution_y = scene.render.resolution_y
        scene.render.resolution_x = settings.size[0]
        scene.render.resolution_y = settings.size[1]
        scene.render.alpha_mode = 'TRANSPARENT' if settings.alpha else 'SKY'
        scene.render.image_settings.file_format = settings.format
        scene.render.image_settings.color_mode = 'RGBA' if settings.format == 'PNG' else 'RGB'
        temp_image = os.path.join(bpy.app.tempdir, "Preview." + settings.format.lower())
        scene.render.filepath = temp_image

        renders = {}
        for obj in scene.objects:
            renders[obj] = obj.hide_render
            obj.hide_render = True

        cam = bpy.data.cameras.new("Preview")
        cam_obj = bpy.data.objects.new("Preview", cam)
        cam_obj.rotation_euler = Euler((radians(63.6), 0.0, radians(46.1)))
        scene.collection.objects.link(cam_obj)
        scene.camera = cam_obj

        scene_world = scene.world
        if not settings.scene_world:
            scene.world = create_world()

        collection = bpy.context.view_layer.active_layer_collection.collection

        objs_dict = {}
        for obj in collection.all_objects:
            if obj == cam_obj:
                continue
            parent = utils.get_parent_root(obj)
            objs_dict.setdefault(parent, set()).add(obj)

        for obj, objs in objs_dict.items():
            objs = utils.copy_objects_in(objs)
            parent, children = next(utils.iter_parent_children_in(objs))
            for child in children:
                if child not in scene.collection.objects.values():
                    scene.collection.objects.link(child)
                child.hide_render = False
            parent.location = Vector((0, 0, 0))
            parent.rotation_euler = obj.rotation_euler
            parent.scale = Vector((1, 1, 1))
            scene.update()
            center, magnitude = utils.align_object_to_grid(parent, children, True, 0, 1, True, False)

            pos = Vector((0, 0, -magnitude * 3))
            pos.rotate(cam_obj.rotation_euler)
            cam_obj.location = center - pos
            cam.clip_start = magnitude * 0.0001
            cam.clip_end = magnitude * 10

            bpy.ops.render.render(write_still=True)
            if obj.name in bpy.data.images:
                image = bpy.data.images[obj.name]
                image.use_fake_user = False
                image.user_clear()
                bpy.data.images.remove(image)
            image = bpy.data.images.load(temp_image)
            image.name = obj.name
            image.pack()
            image.filepath = ""
            image.use_fake_user = True

            for child in children:
                bpy.data.objects.remove(child)

        for obj in renders:
            obj.hide_render = renders[obj]

        if not settings.scene_world:
            bpy.data.worlds.remove(scene.world)
        scene.world = scene_world
        if os.path.exists(temp_image):
            os.remove(temp_image)
        bpy.data.objects.remove(cam_obj)
        bpy.data.cameras.remove(cam)

        scene.render.resolution_x = resolution_x
        scene.render.resolution_y = resolution_y
        scene.camera = scene_camera

        return {'FINISHED'}


def create_world():
    world = bpy.data.worlds.new("Preview")
    world.use_nodes = True
    tree = world.node_tree
    for n in tree.nodes:
        tree.nodes.remove(n)

    out = tree.nodes.new('ShaderNodeOutputWorld')
    mix = tree.nodes.new('ShaderNodeMixShader')
    lp = tree.nodes.new('ShaderNodeLightPath')
    bg1 = tree.nodes.new('ShaderNodeBackground')
    bg2 = tree.nodes.new('ShaderNodeBackground')

    bg1.inputs[0].default_value[:3] = (1.0, 1.0, 1.0)
    bg1.inputs[1].default_value = 0.5
    bg2.inputs[0].default_value[:3] = (0.0, 0.0, 0.0)
    bg2.inputs[1].default_value = 0.0

    links = tree.links
    links.new(out.inputs[0], mix.outputs[0])
    links.new(mix.inputs[0], lp.outputs[0])
    links.new(mix.inputs[1], bg1.outputs[0])
    links.new(mix.inputs[2], bg2.outputs[0])

    return world

classes = (
    LB_GeneratePreviewSettings,
    LB_GeneratePreviewPanel,
    LB_GeneratePreview
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.lb_generate_preview = bpy.props.PointerProperty(type=LB_GeneratePreviewSettings)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.lb_generate_preview
