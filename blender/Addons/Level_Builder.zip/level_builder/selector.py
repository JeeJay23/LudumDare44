import os
import bpy
from . import widget
from . import builder
from . import object_pool
from . import utils


class LB_Selector(bpy.types.Operator):

    bl_idname = "lb.selector"
    bl_label = "Selector"
    bl_description = "Open asset selector"
    bl_options = {'REGISTER'}

    def __init__(self):
        self.draw_handle_2d = None
        self.draw_handle_3d = None
        self.timer_event = None
        self.suspend = False

    def invoke(self, context, event):
        args = (self, context)

        selector_state.reset()
        selector.start()
        context.scene.level_builder.selector.open_selector = True

        self.register_handlers(args, context)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def register_handlers(self, args, context):
        self.draw_handle_2d = bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_2d, args, "WINDOW", "POST_PIXEL")
        self.draw_handle_3d = bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_3d, args, "WINDOW", "POST_VIEW")
        self.timer_event = context.window_manager.event_timer_add(0.1, window=context.window)

    def unregister_handlers(self, context):
        bpy.types.SpaceView3D.draw_handler_remove(self.draw_handle_2d, "WINDOW")
        bpy.types.SpaceView3D.draw_handler_remove(self.draw_handle_3d, "WINDOW")
        context.window_manager.event_timer_remove(self.timer_event)
        self.draw_handle = None

    def modal(self, context, event):
        if event.type in {'TIMER'}:
            if not context.scene.level_builder.selector.open_selector:
                self.close(context)
                return {'FINISHED'}
            return {'PASS_THROUGH'}

        if context.area is None or context.area.type != 'VIEW_3D':
            self.close(context)
            return {'CANCELLED'}

        x, y = event.mouse_region_x, event.mouse_region_y
        w, h = context.area.regions[4].width, context.area.regions[4].height

        if event.type == 'BACK_SLASH':
            if event.value == 'PRESS':
                self.suspend = True
                if context.area:
                    context.area.tag_redraw()
            elif event.value == 'RELEASE':
                self.suspend = False
        if self.suspend:
            builder.suspend(x, y, event)
            return {'PASS_THROUGH'}

        if context.area:
            context.area.tag_redraw()

        if not (0 <= x < w) or not (0 <= y < h):
            return {'PASS_THROUGH'}

        try:
            if not selector_state.is_selected():
                selector.set_size(w, h)
                if selector.handle_event(x, y, event):
                    return {'RUNNING_MODAL'}
            else:
                builder.set_size(w, h)
                if builder.handle_event(x, y, event):
                    return {'RUNNING_MODAL'}
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.report({'ERROR'}, str(e))
            self.close(context)
            return {'CANCELLED'}

        if event.value == 'PRESS' and event.type in ('ESC', 'RIGHTMOUSE'):
            self.close(context)
            return {'FINISHED'}

        return {'RUNNING_MODAL'}

    def close(self, context):
        context.scene.level_builder.selector.open_selector = False
        selector.close()
        builder.close()
        self.unregister_handlers(context)

    def draw_callback_2d(self, op, context):
        if not self.suspend:
            if not selector_state.is_selected():
                selector.set_size(context.area.regions[4].width, context.area.regions[4].height)
                selector.draw()
            else:
                builder.set_size(context.area.regions[4].width, context.area.regions[4].height)
                builder.draw()

    def draw_callback_3d(self, op, context):
        if not self.suspend and selector_state.is_selected():
            builder.draw_gizmo()


class SelectorState:

    def __init__(self):
        self.selected = False
        self.selected_objects = []

    def is_selected(self):
        return self.selected

    def select(self):
        self.selected = True
        object_pool.set_pool(self.selected_objects)
        builder.start()

    def reset(self):
        self.selected = False
        self.selected_objects = []
        selector.set_dirty()

    def check_object(self, item):
        return item in self.selected_objects

    def toggle_object(self, item):
        if self.check_object(item):
            self.selected_objects.remove(item)
        else:
            self.selected_objects.append(item)

    def add_object(self, item):
        if not self.check_object(item):
            self.selected_objects.append(item)

    def remove_object(self, item):
        if self.check_object(item):
            self.selected_objects.remove(item)


class Selector(widget.Base):

    def __init__(self):
        self.clear_collection = False
        self.navigation_bar = None
        self.item_grid = None
        super().__init__()

    def start(self):
        settings = bpy.context.scene.level_builder.selector
        self.clear_collection = True

        self.navigation_bar = CollectionBar(8, 8) if settings.flatten_collection else LocationBar(8, 8)
        self.add(self.navigation_bar)
        self.item_grid = ItemGrid(8, 8)
        self.add(self.item_grid)
        self.on_change()

    def close(self):
        library_datas.clear_library_previews()
        self.remove_all()
        self.set_dirty()

    def on_change(self):
        if self.navigation_bar is not None:
            self.navigation_bar.set_size(self.width - 16, self.navigation_bar.rect_height)
        if self.item_grid is not None:
            self.item_grid.set_position(8, self.navigation_bar.rect_height + 16)
            self.item_grid.set_size(self.width - 16, self.height - self.navigation_bar.rect_height - 24)

    def check_builder_collection(self):
        if self.clear_collection:
            self.clear_collection = False

            builder = utils.get_collection("Level Builder")
            for obj in builder.objects.values():
                builder.objects.unlink(obj)


class LocationBar(widget.Base):

    text_size = 16
    item_height = 24

    normal_color = (0.2, 0.2, 0.8, 0.4)
    sub_color = (0.2, 0.8, 0.2, 0.2)
    color = (normal_color, sub_color)

    normal_highlight = (0.2, 0.2, 0.8, 0.8)
    sub_highlight = (0.2, 0.8, 0.2, 0.4)
    highlight = (normal_highlight, sub_highlight)

    indices_rect = ((0, 1, 2), (0, 2, 3), (4, 5, 6), (4, 6, 7))
    indices_frame = ((0, 1), (1, 5), (5, 6), (6, 2), (2, 3), (3, 0))

    def __init__(self, x, y):
        self.items = []
        self.rect = widget.Rect()
        self.rect.set_color((0.4, 0.4, 0.4, 0.8))
        self.rect_height = 0
        super().__init__(x, y)

    def on_change(self):
        if self.rect is not None:
            self.rect.set_size(self.width, self.rect_height)

    def update(self, x, y):
        self.update_item()
        self.update_height()
        super().update(x, y)

    def update_height(self):
        height = 0
        for item in self.items:
            if item.y + item.height + 8 > height:
                height = item.y + item.height + 8
        if self.rect_height != height:
            self.rect_height = height
            self.set_dirty()
            self.parent.set_dirty()

    def update_item(self):
        self.items = []
        self.remove_all()
        self.add(self.rect)

        settings = bpy.context.scene.level_builder.selector

        x, y = 8, 8

        if settings.selected_library != -1:
            lib = settings.libraries[settings.selected_library]
            if not lib.enable:
                settings.selected_library = -1

        if settings.selected_library == -1:
            for index, lib in enumerate(settings.libraries):
                if not lib.enable:
                    continue
                name = bpy.path.display_name_from_filepath(lib.lib_file)
                item = self.add_item(x, y, name, 1, start=True)
                item.set_mouse_down(self.select_library, index)
                x, y = item.x + item.width + 1 + 12, item.y
        else:
            lib = settings.libraries[settings.selected_library]
            colls_data = library_datas.get_collections_data(lib.lib_file)

            item = self.add_item(x, y, "", 0, start=True)
            item.set_mouse_down(self.select_library, -1)
            x, y = item.x + item.width + 1, item.y

            name = bpy.path.display_name_from_filepath(lib.lib_file)
            item = self.add_item(x, y, name, 0)
            item.set_mouse_down(self.select_collection, "")
            x, y = item.x + item.width + 1, item.y

            coll_data = colls_data.get(lib.selected_collection)
            if coll_data is None:
                parent = None
                coll = lib.selected_collection = ""
                children = [coll for coll, data in colls_data.items() if data.get('Parent') is None]
            else:
                parent = coll = lib.selected_collection
                children = coll_data['Children']

            parents = []
            while parent is not None:
                parents.append(parent)
                parent = colls_data[parent].get('Parent')
            for parent in parents[::-1]:
                right = parent == coll and len(children) == 0
                item = self.add_item(x, y, parent, 0, end=right)
                item.set_mouse_down(self.select_collection, parent)
                x, y = item.x + item.width + 1, item.y

            x += 8
            for name in children:
                item = self.add_item(x, y, name, 1, end=True)
                item.set_mouse_down(self.select_collection, name)
                x, y = item.x + item.width + 1 + 8, item.y

    def select_library(self, widget, event, param):
        settings = bpy.context.scene.level_builder.selector
        settings.selected_library = param
        self.parent.set_dirty()

    def select_collection(self, widget, event, param):
        settings = bpy.context.scene.level_builder.selector
        lib = settings.libraries[settings.selected_library]
        lib.selected_collection = param
        self.parent.set_dirty()

    def add_item(self, x, y, name, color, start=False, end=False):
        text = widget.Text(0 if start else 4, -2)
        text.set_text(name)
        text.set_text_size(self.text_size)
        text.set_color((1.0, 1.0, 0.0, 1.0))
        width = text.get_widget_size()[0] + (12 if start else 16)
        text.set_size(width, 26)

        if x + width + 8 > self.width:
            x = 8
            y += self.item_height + 8

        left = 0.0 if start else self.item_height / 4 / width
        right = 1.0 if end else 1.0 + self.item_height / 4 / width

        item = widget.Rect(x, y, width, self.item_height)
        item.set_color(self.color[color])
        item.set_highlight(self.highlight[color])
        item.set_shape(self.indices_rect, self.get_shape(left, right))
        self.add(item)

        frame = widget.Frame(0, 0, width, self.item_height)
        frame.set_shape(self.indices_frame, self.get_shape(left, right))
        item.add(frame)

        item.add(text)
        self.items.append(item)
        return item

    def get_shape(self, left, right):
        vertices = ((0.0, 0.0), (left, 0.5), (right, 0.5), (1.0, 0.0), (left, 0.5), (0.0, 1.0), (1.0, 1.0), (right, 0.5))
        return vertices


class CollectionBar(widget.Base):

    text_size = 16
    item_height = 24

    normal_color = (0.2, 0.2, 0.8, 0.4)
    sub_color = (0.2, 0.8, 0.2, 0.2)
    color = (normal_color, sub_color)

    normal_highlight = (0.2, 0.2, 0.8, 0.8)
    sub_highlight = (0.2, 0.8, 0.2, 0.4)
    highlight = (normal_highlight, sub_highlight)

    def __init__(self, x, y):
        self.items = []
        self.rect = widget.Rect()
        self.rect.set_color((0.4, 0.4, 0.4, 0.8))
        self.rect_height = 0
        super().__init__(x, y)

    def on_change(self):
        if self.rect is not None:
            self.rect.set_size(self.width, self.rect_height)

    def update(self, x, y):
        self.update_item()
        self.update_height()
        super().update(x, y)

    def update_height(self):
        height = 0
        for item in self.items:
            if item.y + item.height + 8 > height:
                height = item.y + item.height + 8
        if self.rect_height != height:
            self.rect_height = height
            self.set_dirty()
            self.parent.set_dirty()

    def update_item(self):
        self.items = []
        self.remove_all()
        self.add(self.rect)

        settings = bpy.context.scene.level_builder.selector

        selected_library = ""
        if settings.selected_library != -1:
            lib = settings.libraries[settings.selected_library]
            if not lib.enable:
                settings.selected_library = -1
            else:
                selected_library = bpy.path.display_name_from_filepath(lib.lib_file)

        x = y = 8
        for index, lib in enumerate(settings.libraries):
            if not lib.enable:
                continue
            name = bpy.path.display_name_from_filepath(lib.lib_file)
            item = self.add_item(x, y, name, 0, name == selected_library)
            item.set_mouse_down(self.select_library, index)
            x, y = item.x + item.width + 1, item.y
        x += 12

        if settings.selected_library != -1:
            lib = settings.libraries[settings.selected_library]
            colls_data = library_datas.get_collections_data(lib.lib_file)
            colls = [coll for coll, data in colls_data.items() if len(data['Objects']) > 0]

            for coll in sorted(colls):
                item = self.add_item(x, y, coll, 1, coll == lib.selected_collection)
                item.set_mouse_down(self.select_collection, coll)
                x, y = item.x + item.width + 1, item.y

    def select_library(self, widget, event, param):
        settings = bpy.context.scene.level_builder.selector
        settings.selected_library = param
        self.parent.set_dirty()

    def select_collection(self, widget, event, param):
        settings = bpy.context.scene.level_builder.selector
        lib = settings.libraries[settings.selected_library]
        lib.selected_collection = param
        self.parent.set_dirty()

    def add_item(self, x, y, name, color, selected):
        text = widget.Text(0, -2)
        text.set_text(name)
        text.set_text_size(self.text_size)
        text.set_color((1.0, 1.0, 0.0, 1.0))
        width = text.get_widget_size()[0] + 16
        text.set_size(width, 26)

        if x + width + 8 > self.width:
            x = 8
            y += self.item_height + 8

        item = widget.Rect(x, y, width, self.item_height)
        item.set_color(self.highlight[color] if selected else self.color[color])
        item.set_highlight(self.highlight[color])
        self.add(item)

        frame = widget.Frame(0, 0, width, self.item_height)
        if selected:
            frame.set_color((1.0, 1.0, 1.0, 1.0))
        item.add(frame)

        item.add(text)
        self.items.append(item)
        return item


class ItemGrid(widget.Base):

    text_size = 16
    item_height = 24

    color = (0.2, 0.2, 0.8, 0.4)
    highlight = (0.2, 0.2, 0.8, 0.8)

    def __init__(self, x, y):
        self.items = []
        self.images = {}
        self.rect = widget.Rect()
        self.rect.set_color((0.4, 0.4, 0.4, 0.8))
        super().__init__(x, y)
        self.clip = True
        self.scrollable = True

    def update(self, x, y):
        self.update_item()
        super().update(x, y)

    def mouse_wheel(self, x, y, v, event):
        if self.is_inside(x, y) and event.ctrl:
            settings = bpy.context.scene.level_builder.selector
            size = settings.item_size
            size += v * -16
            size = sorted((32, size, 512))[1]
            self.scroll_y *= size / settings.item_size
            settings.item_size = size
            self.set_dirty()
            return True
        return super().mouse_wheel(x, y, v, event)

    def update_item(self):
        self.items = []
        self.remove_all()
        self.add(self.rect)

        settings = bpy.context.scene.level_builder.selector
        if settings.selected_library == -1:
            self.rect.set_size(self.width, 0)
            self.scroll_y = 0
            return

        lib = settings.libraries[settings.selected_library]
        colls_data = library_datas.get_collections_data(lib.lib_file)
        coll_data = colls_data.get(lib.selected_collection, {})
        objs = coll_data.get('Objects', [])
        images = library_datas.get_library_previews(lib.lib_file, objs)

        x = y = 8
        w = h = settings.item_size
        for obj in sorted(objs):
            img = images.get(obj)
            obj_item = (lib.lib_file, obj, img)
            item = self.add_item(x, y, w, h, obj, img, selector_state.check_object(obj_item))
            item.set_mouse_down(self.select_object, obj_item)
            x, y = item.x + item.width + 8, item.y

        if len(self.items) > 0:
            h = max([item.y + item.height + 8 for item in self.items])
            self.rect.set_size(self.width, h)
            h = h - self.height
            if h > 0 and self.scroll_y > h:
                self.scroll_y = h
        else:
            self.rect.set_size(self.width, 0)
            self.scroll_y = 0

    def select_object(self, widget, event, param):
        if event.shift:
            selector_state.toggle_object(param)
        else:
            selector_state.add_object(param)

        if not event.shift:
            selector_state.select()
            # self.remove_all()
            # self.parent.close()
        else:
            self.parent.set_dirty()

    def add_item(self, x, y, w, h, name, image, selected):
        if x + w + 8 > self.width:
            x = 8
            y += h + 22 + 8

        item = widget.Rect(x, y, w, h + 22)
        item.set_color((0.2, 0.2, 0.8, 0.8) if selected else (0.2, 0.2, 0.8, 0.4))
        item.set_highlight((0.2, 0.2, 0.8, 0.8))
        self.add(item)

        rect = widget.Rect(2, h + 2, w - 4, 18)
        if selected:
            rect.set_color((1.0, 1.0, 0.0, 1.0))
        item.add(rect)
        text = widget.Text(2, h + 0, w - 4, 18)
        text.set_text(name)
        text.set_text_size(11)
        item.add(text)

        if image is not None:
            img = widget.Image(0, 0, w, h)
            img.set_image(image)
            item.add(img)

        self.items.append(item)
        return item


class Library_Datas:

    def __init__(self):
        self.libraries_data = {}
        self.libraries_preview = {}

    def clear_library_previews(self):
        for preview in self.libraries_preview.values():
            for image in preview.values():
                bpy.data.images.remove(image)
        utils.get_bpy_area('OUTLINER').tag_redraw()
        self.libraries_preview = {}

    def get_library_previews(self, lib, names):
        if len(names) == 0:
            return {}

        previews = self.libraries_preview.setdefault(lib, {})
        loads = [name for name in names if name not in previews]
        images = {name: previews[name] for name in names if name in previews}

        with bpy.data.libraries.load(lib, link=True) as (data_from, data_to):
            data_to.images = [img for img in data_from.images if img in loads]

        for image in data_to.images:
            image.use_fake_user = False
            images[image.name] = image
            previews[image.name] = image

        return images

    def get_library_preview(self, lib, name):
        previews = self.libraries_preview.get(lib)
        if previews is None:
            return None
        return previews.get(name)

    def get_collections_data(self, lib):
        data = self.libraries_data.get(lib)
        if data is None:
            data = self.update_data(lib)
        return data[0]

    def get_objects_data(self, lib):
        data = self.libraries_data.get(lib)
        if data is None:
            data = self.update_data(lib)
        return data[1]

    def update_data(self, lib):
        all_blocks = []
        for attr in dir(bpy.data):
            blocks = getattr(bpy.data, attr)
            if isinstance(blocks, bpy.types.bpy_prop_collection):
                if hasattr(blocks, 'remove'):
                    all_blocks.append(blocks)

        keep_blocks = {block for blocks in all_blocks for block in blocks if block.users == 0}

        with bpy.data.libraries.load(lib, link=True) as (data_from, data_to):
            data_to.scenes = data_from.scenes

        objs = set()
        objs_data = {}
        for scene in data_to.scenes:
            for obj in scene.objects:
                if obj not in objs:
                    objs.add(obj)
                    parent = obj
                    while parent.parent is not None:
                        parent = parent.parent
                    objs_data.setdefault(parent.name, []).append(obj.name)

        colls = set()
        colls_data = {}
        for scene in data_to.scenes:
            self.get_collection_data(scene.collection, scene.name, colls, colls_data)
        for coll, coll_data in colls_data.items():
            for child in coll_data['Children']:
                colls_data[child]['Parent'] = coll

        data = [colls_data, objs_data]
        self.libraries_data[lib] = data

        for scene in data_to.scenes:
            if scene != bpy.context.scene:
                bpy.data.scenes.remove(scene)

        repeat = True
        while repeat:
            repeat = False
            for blocks in all_blocks:
                for block in blocks:
                    if block.users == 0 and block not in keep_blocks:
                        blocks.remove(block, do_unlink=False)
                        repeat = True

        return data

    def get_collection_data(self, coll, name, colls, colls_data):
        if coll not in colls:
            colls.add(coll)
            coll_data = colls_data.setdefault(name, {})
            coll_data['Parent'] = None
            coll_data['Children'] = [child.name for child in coll.children]
            coll_data['Objects'] = [obj.name for obj in coll.objects if obj.parent is None]

            for child in coll.children:
                self.get_collection_data(child, child.name, colls, colls_data)
                coll.children.unlink(child)

selector_state = SelectorState()
selector = Selector()
library_datas = Library_Datas()

reset = selector_state.reset
check_builder_collection = selector.check_builder_collection
get_objects_data = library_datas.get_objects_data

classes = (
    LB_Selector,
)

addon_keymaps = []


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    kcfg = bpy.context.window_manager.keyconfigs.addon
    if kcfg:
        km = kcfg.keymaps.new(name="3D View", space_type='VIEW_3D')
        kmi = km.keymap_items.new(LB_Selector.bl_idname, "RET", 'PRESS', shift=True)
        addon_keymaps.append((km, kmi))


def unregister():
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()

    for cls in classes:
        bpy.utils.unregister_class(cls)
