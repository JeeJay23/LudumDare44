import math
import random
import bpy
import bmesh
import bpy.utils.previews
from mathutils import Vector, Quaternion, Matrix
from . import selector
from . import utils


class ObjectPool:

    def __init__(self):
        self.previews = {}
        self.object_datas = []
        self.sequence = []
        self.seq_index = 0
        self.saved_seq_index = 0

    def set_pool(self, items):
        object_pool = bpy.context.scene.level_builder.object_pool
        object_pool.objects.clear()
        object_pool.order = ""
        self.object_datas = []
        self.sequence = []
        self.seq_index = 0

        for lib, obj, img in items:
            data = object_pool.objects.add()
            data.lib_file = lib
            data.object_name = obj
            self.object_datas.append(data)

            if img is not None:
                if lib in self.previews:
                    pcoll = self.previews[lib]
                else:
                    pcoll = bpy.utils.previews.new()
                    self.previews[lib] = pcoll

                if obj in pcoll:
                    image_preivew = pcoll[obj]
                else:
                    image_preivew = pcoll.new(obj)

                img = img.copy()
                img.scale(48, 48)
                image_preivew.image_size = (48, 48)
                image_preivew.image_pixels_float = img.pixels[:]
                bpy.data.images.remove(img)

            objs_data = selector.get_objects_data(lib)
            objs = objs_data.get(obj, [obj])[:]
            with bpy.data.libraries.load(lib, link=True) as (data_from, data_to):
                data_to.objects = objs
            data.cached_objs = data_to.objects

    def clear(self):
        bpy.context.scene.level_builder.object_pool.objects.clear()
        for pcoll in self.previews.values():
            bpy.utils.previews.remove(pcoll)
        self.previews = {}
        for data in self.object_datas:
                utils.remove_objects_in(data.cached_objs)
        self.object_datas = []

    def get_count(self):
        return len(self.object_datas)

    def get_preview(self, lib, obj):
        if lib in self.previews:
            if obj in self.previews[lib]:
                return self.previews[lib][obj]
        return None

    def get_object_datas(self, index):
        return self.object_datas[index]

    def get_object_randomness(self, index):
        item = self.get_object_datas(index)
        if not item.override:
            object_pool = bpy.context.scene.level_builder.object_pool
            settings = bpy.context.scene.level_builder.builder
            randomness = (object_pool.grid_mode_randomness, object_pool.snap_mode_randomness, object_pool.paint_mode_randomness)
            randomness = randomness[int(settings.mode)]
        else:
            randomness = item.randomness
        return randomness

    def restart_seq_index(self, index=0):
        self.saved_seq_index = self.seq_index
        self.seq_index = index
        return self.saved_seq_index

    def restore_seq_index(self):
        self.seq_index = self.saved_seq_index

    def get_object_order(self):
        object_pool = bpy.context.scene.level_builder.object_pool
        seq = []
        try:
            seq = [int(item) for item in object_pool.order.split(",")]
        except:
            pass
        if len(seq) == 0:
            seq = [i for i in range(self.get_count())]
        return seq

    def get_object_indices(self, count):
        object_pool = bpy.context.scene.level_builder.object_pool
        if object_pool.random:
            return self.get_random_indices(count)
        else:
            return self.get_sequence_indices(count)

    def get_random_indices(self, count):
        length = self.get_count()
        weights = [item.weight for item in self.object_datas]
        indices = random.choices(range(length), weights=weights, k=count)
        return indices

    def get_sequence_indices(self, count):
        seq = self.get_object_order()
        if seq != self.sequence:
            self.sequence = seq
            self.seq_index = 0

        seq = [self.sequence[(self.seq_index + i) % len(self.sequence)] for i in range(count)]
        self.seq_index += count
        return seq

pool = ObjectPool()
set_pool = pool.set_pool
clear = pool.clear
get_count = pool.get_count
get_preview = pool.get_preview
restart_seq_index = pool.restart_seq_index
restore_seq_index = pool.restore_seq_index
get_object_indices = pool.get_object_indices
get_object_datas = pool.get_object_datas


def link_collection(obj, collection, check=False):
    if collection is None:
        collection = bpy.context.view_layer.active_layer_collection.collection
    builder = utils.get_collection("Level Builder")
    if builder == collection:
        collection = utils.get_collection("Level Builder.001")
    if not check or obj not in collection.objects.values():
        collection.objects.link(obj)
    if not check or obj not in builder.objects.values():
        builder.objects.link(obj)


def get_object(index, collection=None):
    selector.check_builder_collection()

    index %= get_count()
    data = pool.get_object_datas(index)
    objs = utils.copy_objects_in(data.cached_objs)
    for obj in objs:
        link_collection(obj, collection)
    parent, children = next(utils.iter_parent_children_in(objs))

    parent.location[:] = 0.0, 0.0, 0.0
    parent.rotation_euler[:] = 0.0, 0.0, 0.0
    parent.scale[:] = 1.0, 1.0, 1.0

    return parent, children


def get_randomness_matrix(index, location, normal, align):
    index %= get_count()
    randomness = pool.get_object_randomness(index)

    loc = location if location is not None else Vector((0.0, 0.0, 0.0))
    nor = normal if normal is not None else Vector((0.0, 0.0, 1.0))

    x = random_range(randomness.offset_min[0], randomness.offset_max[0], randomness.offset_step)
    y = random_range(randomness.offset_min[1], randomness.offset_max[1], randomness.offset_step)
    z = random_range(randomness.offset_min[2], randomness.offset_max[2], randomness.offset_step)
    if randomness.use_random:
        loc = loc + Vector((x, y, z))

    angle = random_range(randomness.rotate_min, randomness.rotate_max, randomness.rotate_step)
    axis = Vector((random.random(), random.random(), random.random())).normalized()
    quat = utils.align_rotation(align, nor)
    if randomness.use_random:
        axis = nor if randomness.rotate_normal else axis
        quat = Quaternion(axis, angle) @ quat
    rotation_matrix = quat.to_matrix().to_4x4()

    scale = random_range(randomness.scale_min, randomness.scale_max, randomness.scale_step)
    if randomness.use_random:
        scale_matrix = Matrix.Scale(scale, 4)

    if location is None:
        return None
    if not randomness.use_random:
        return Matrix.Translation(location) @ rotation_matrix
    return Matrix.Translation(loc) @ rotation_matrix @ scale_matrix


def random_range(min, max, step):
    if math.isclose(min, max) or math.isclose(step, 0):
        return min
    r = int(round((max - min) / step))
    if r <= 0:
        random.randrange(1)
        return min
    return random.randrange(r) * step + min


def create_instancers(instancers, instancers_matrices, collection=None):
    instancer_objs = []
    for i, instancer in enumerate(instancers):
        matrices = instancers_matrices[i]
        if instancer is None:
            parent, children = get_object(i, collection)
            instancer = create_instancer(None, parent, matrices)
            link_collection(instancer, collection)
            instancers[i] = instancer
            instancer_objs.extend(children)
        else:
            create_instancer(instancer, None, matrices)

    bpy.ops.object.select_all(action='DESELECT')
    for obj in instancer_objs:
        obj.select_set(True)
    bpy.ops.object.hide_view_set()

    return instancers, instancer_objs


def create_instancer(instancer, obj, matrices):
    if instancer is None:
        name = obj.name + " (Instancer)"
        mesh = bpy.data.meshes.new(name)
        create_instancer_mesh(mesh, matrices)
        instancer = bpy.data.objects.new(name, mesh)
        instancer.instance_type = 'FACES'
        instancer.show_instancer_for_viewport = False
        instancer.show_instancer_for_render = False
        instancer.use_instance_faces_scale = True
        instancer.instance_faces_scale = 10
        instancer.location[:] = 0.0, 0.0, 0.0
        instancer.rotation_euler[:] = 0.0, 0.0, 0.0
        instancer.scale[:] = 1.0, 1.0, 1.0
    else:
        if instancer.type == 'MESH':
            create_instancer_mesh(instancer.data, matrices)

    if obj is not None:
        obj.parent = instancer

    return instancer

quad_vertices = ((-0.5, -0.5, 0.0), (0.5, -0.5, 0.0), (0.5, 0.5, 0.0), (-0.5, 0.5, 0.0))
quad_vertices = [0.1 * Vector(v) for v in quad_vertices]


def create_instancer_mesh(mesh, matrices):
    bm = bmesh.new()
    for i, mat in enumerate(matrices):
        if mat is None:
            continue
        v1 = bm.verts.new(mat @ quad_vertices[0])
        v2 = bm.verts.new(mat @ quad_vertices[1])
        v3 = bm.verts.new(mat @ quad_vertices[2])
        v4 = bm.verts.new(mat @ quad_vertices[3])
        bm.verts.index_update()
        bm.faces.new((v1, v2, v3, v4))
    bm.to_mesh(mesh)
    bm.free()


def make_instancers_real(instancers):
    bpy.ops.object.select_all(action='DESELECT')
    for instancer in instancers:
        instancer.select_set(True)
    bpy.ops.object.duplicates_make_real(use_base_parent=False, use_hierarchy=True)
