import bpy
import bgl
import gpu
from mathutils import Vector, Matrix
from gpu_extras.batch import batch_for_shader
from gpu_extras.presets import draw_circle_2d
from . import utils


class Grid:

    vertex_shader = '''
        uniform mat4 invertViewProjectionMatrix;

        in vec3 pos;
        out vec3 n;
        out vec3 f;

        void main()
        {
            vec4 v = invertViewProjectionMatrix * vec4(pos.xy, 0.0, 1.0);
            n = v.xyz / v.w;
            v = invertViewProjectionMatrix * vec4(pos.xy, 1.0, 1.0);
            f = v.xyz / v.w;
            gl_Position = vec4(pos, 1.0);
        }
    '''

    fragment_shader = '''
        uniform vec4 color1;
        uniform vec4 color2;
        uniform vec3 grid_size;
        uniform vec3 grid_location;
        uniform vec3 grid_normal;
        uniform vec3 grid_offset;
        uniform vec3 eye_location;
        uniform vec3 eye_direction;
        uniform mat4 viewProjectionMatrix;
        uniform bool is_perspective;

        in vec3 n;
        in vec3 f;

        void main()
        {
            vec3 o = grid_location * grid_normal;
            float t = dot(-(n - o) / (f - n), grid_normal);
            vec3 p = n + t * (f - n);

            vec3 half_size = grid_size / 2.0;
            vec3 grid_domain = abs(mod(p + grid_offset + half_size, grid_size) - half_size);
            grid_domain = max(grid_domain, grid_normal) / fwidth(p);
            float grid = min(min(grid_domain.x, grid_domain.y), grid_domain.z);
            vec4 color = mix(color1, color2, grid);

            vec3 view = is_perspective ? normalize(eye_location - p) : eye_direction;
            float angle = abs(dot(view, grid_normal));
            color.a *= 1 - pow(1 - angle, 2);
            color.a *= 1 - smoothstep(0, 0.8, t - 0.2);
            if (is_perspective) color *= float(t > 0.0);

            vec4 pos = viewProjectionMatrix * vec4(p, 1.0);
            float d = pos.z / pos.w;
            float far = gl_DepthRange.far;
            float near = gl_DepthRange.near;
            float depth = (((far - near) * d) + near + far) / 2.0;
            depth = depth - 6e-8 - fwidth(depth);

            gl_FragColor = color;
            gl_FragDepth = depth;
        }
    '''

    def __init__(self):
        self.axis = [Vector((1.0, 0.0, 0.0)), Vector((0.0, 1.0, 0.0)), Vector((0.0, 0.0, 1.0))]

        self.indices = ((0, 1, 2), (0, 2, 3))
        self.vertices = ((-1.0, -1.0, 1.0), (-1.0, 1.0, 1.0), (1.0, 1.0, 1.0), (1.0, -1.0, 1.0))
        self.shader = gpu.types.GPUShader(self.vertex_shader, self.fragment_shader)
        self.batch = batch_for_shader(self.shader, 'TRIS', {"pos": self.vertices}, indices=self.indices)

    def draw(self):
        settings = bpy.context.scene.level_builder.builder

        matrix = bpy.context.region_data.perspective_matrix
        offset = (settings.grid_size / 2) if settings.grid_offset else Vector((0.0, 0.0, 0.0))
        gird_normal = self.axis[int(settings.grid_direction)]
        eye_location = utils.get_viewport_eye_location()
        dist = utils.get_distance_to_plane(eye_location, settings.grid_location, gird_normal)
        is_perspective = bpy.context.space_data.region_3d.is_perspective

        self.shader.bind()
        self.shader.uniform_float("viewProjectionMatrix", matrix)
        self.shader.uniform_float("invertViewProjectionMatrix", matrix.inverted())
        self.shader.uniform_float("color1", settings.grid_color1)
        self.shader.uniform_float("color2", settings.grid_color2)
        self.shader.uniform_float("grid_size", settings.grid_size)
        self.shader.uniform_float("grid_location", settings.grid_location)
        self.shader.uniform_float("grid_normal", gird_normal)
        self.shader.uniform_float("grid_offset", offset)
        self.shader.uniform_float("eye_location", eye_location)
        self.shader.uniform_float("eye_direction", utils.get_viewport_eye_direction())
        self.shader.uniform_bool("is_perspective", [is_perspective])
        bgl.glEnable(bgl.GL_BLEND)
        self.batch.draw(self.shader)
        bgl.glDisable(bgl.GL_BLEND)


class Checker:

    vertex_shader = '''
        uniform mat4 invertViewProjectionMatrix;

        in vec3 pos;
        out vec3 n;
        out vec3 f;

        void main()
        {
            vec4 v = invertViewProjectionMatrix * vec4(pos.xy, 0.0, 1.0);
            n = v.xyz / v.w;
            v = invertViewProjectionMatrix * vec4(pos.xy, 1.0, 1.0);
            f = v.xyz / v.w;
            gl_Position = vec4(pos, 1.0);
        }
    '''

    fragment_shader = '''
        uniform vec4 color1;
        uniform vec4 color2;
        uniform vec3 grid_size;
        uniform vec3 grid_location;
        uniform vec3 grid_normal;
        uniform vec3 grid_offset;
        uniform vec3 eye_location;
        uniform vec3 eye_direction;
        uniform mat4 viewProjectionMatrix;
        uniform bool is_perspective;

        in vec3 n;
        in vec3 f;

        void main()
        {
            vec3 o = grid_location * grid_normal;
            float t = dot(-(n - o) / (f - n), grid_normal);
            vec3 p = n + t * (f - n);

            vec3 uv = (p + grid_offset) / grid_size;
            vec3 w = fwidth(uv);
            vec3 p0 = (uv - 0.5 * w) / 2.0;
            vec3 p1 = (uv + 0.5 * w) / 2.0;
            p0 = floor(p0) + 2.0 * max(p0 - floor(p0) - 0.5, 0.0);
            p1 = floor(p1) + 2.0 * max(p1 - floor(p1) - 0.5, 0.0);
            vec3 i = clamp((p1 - p0) / w, 0.0, 1.0) * (1.0 - grid_normal);
            float checker = abs(1 - i.x - i.y - i.z);
            vec4 color = mix(color1, color2, checker);

            vec3 view = is_perspective ? normalize(eye_location - p) : eye_direction;
            float angle = abs(dot(view, grid_normal));
            color.a *= 1 - pow(1 - angle, 2);
            color.a *= 1 - smoothstep(0, 0.8, t - 0.2);
            if (is_perspective) color *= float(t > 0.0);

            vec4 pos = viewProjectionMatrix * vec4(p, 1.0);
            float d = pos.z / pos.w;
            float far = gl_DepthRange.far;
            float near = gl_DepthRange.near;
            float depth = (((far - near) * d) + near + far) / 2.0;
            depth = depth - 6e-8 - fwidth(depth);

            gl_FragColor = color;
            gl_FragDepth = depth;
        }
    '''

    def __init__(self):
        self.axis = [Vector((1.0, 0.0, 0.0)), Vector((0.0, 1.0, 0.0)), Vector((0.0, 0.0, 1.0))]

        self.indices = ((0, 1, 2), (0, 2, 3))
        self.vertices = ((-1.0, -1.0, 1.0), (-1.0, 1.0, 1.0), (1.0, 1.0, 1.0), (1.0, -1.0, 1.0))
        self.shader = gpu.types.GPUShader(self.vertex_shader, self.fragment_shader)
        self.batch = batch_for_shader(self.shader, 'TRIS', {"pos": self.vertices}, indices=self.indices)

    def draw(self):
        settings = bpy.context.scene.level_builder.builder

        matrix = bpy.context.region_data.perspective_matrix
        offset = (settings.grid_size / 2) if settings.grid_offset else Vector((0.0, 0.0, 0.0))
        gird_normal = self.axis[int(settings.grid_direction)]
        eye_location = utils.get_viewport_eye_location()
        dist = utils.get_distance_to_plane(eye_location, settings.grid_location, gird_normal)
        is_perspective = bpy.context.space_data.region_3d.is_perspective

        self.shader.bind()
        self.shader.uniform_float("viewProjectionMatrix", matrix)
        self.shader.uniform_float("invertViewProjectionMatrix", matrix.inverted())
        self.shader.uniform_float("color1", settings.grid_color1)
        self.shader.uniform_float("color2", settings.grid_color2)
        self.shader.uniform_float("grid_size", settings.grid_size)
        self.shader.uniform_float("grid_location", settings.grid_location)
        self.shader.uniform_float("grid_normal", gird_normal)
        self.shader.uniform_float("grid_offset", offset)
        self.shader.uniform_float("eye_location", eye_location)
        self.shader.uniform_float("eye_direction", utils.get_viewport_eye_direction())
        self.shader.uniform_bool("is_perspective", [is_perspective])
        bgl.glEnable(bgl.GL_BLEND)
        self.batch.draw(self.shader)
        bgl.glDisable(bgl.GL_BLEND)


class Circle:

    vertex_shader = '''
        uniform mat4 viewProjectionMatrix;
        uniform mat4 worldMatrix;

        in vec3 pos;
        out vec4 p;
        out vec2 crood;

        void main()
        {
            p = viewProjectionMatrix * worldMatrix * vec4(pos, 1.0);
            crood = pos.xy;
            gl_Position = p;
        }
    '''

    fragment_shader = '''
        uniform vec4 color;
        uniform bool fill;

        in vec4 p;
        in vec2 crood;

        void main()
        {
            float radius = length(crood);
            float signedDistance = radius - 1.0;
            float gradient = fwidth(signedDistance);
            float rangeFromLine = abs((signedDistance + gradient) / gradient);
            float lineWeight = clamp(1 - rangeFromLine, fill ? color.a : 0.0, 1.0);
            if (radius > 1) lineWeight = 0.0;
            gl_FragColor = vec4(color.rgb, lineWeight);
        }
    '''

    def __init__(self):
        self.indices = ((0, 1, 2), (0, 2, 3))
        self.vertices = ((-1.0, -1.0, 0.0), (-1.0, 1.0, 0.0), (1.0, 1.0, 0.0), (1.0, -1.0, 0.0))
        self.shader = gpu.types.GPUShader(self.vertex_shader, self.fragment_shader)
        self.batch = batch_for_shader(self.shader, 'TRIS', {"pos": self.vertices}, indices=self.indices)

        self.color = (0.8, 0.8, 0.8, 0.3)
        self.location = Vector((0.0, 0.0, 0.0))
        self.normal = Vector((0.0, 0.0, 1.0))
        self.radius = 1

    def set_color(self, color):
        self.color = color

    def set_location(self, location):
        self.location = location

    def set_normal(self, normal):
        self.normal = normal

    def set_radius(self, radius):
        self.radius = radius

    def draw(self):
        view_project_matrix = bpy.context.region_data.perspective_matrix

        quat = Vector((0.0, 0.0, 1.0)).rotation_difference(self.normal)
        rotation_matrix = quat.to_matrix().to_4x4()
        world_matrix = Matrix.Translation(self.location) @ rotation_matrix @ Matrix.Scale(self.radius, 4)

        self.shader.bind()
        self.shader.uniform_float("viewProjectionMatrix", view_project_matrix)
        self.shader.uniform_float("worldMatrix", world_matrix)
        self.shader.uniform_float("color", self.color)
        bgl.glEnable(bgl.GL_BLEND)
        self.shader.uniform_bool("fill", [True])
        self.batch.draw(self.shader)
        bgl.glDisable(bgl.GL_DEPTH_TEST)
        self.shader.uniform_bool("fill", [False])
        self.batch.draw(self.shader)
        bgl.glEnable(bgl.GL_DEPTH_TEST)
        bgl.glDisable(bgl.GL_BLEND)


class Points:

    vertex_shader = '''
        uniform mat4 viewProjectionMatrix;

        in vec3 pos;
        in vec4 color;
        out vec4 c;

        void main()
        {
            c = color;
            gl_Position = viewProjectionMatrix * vec4(pos, 1.0);
        }
    '''

    fragment_shader = '''
        in vec4 c;

        void main()
        {
            float radius = length(gl_PointCoord - vec2(0.5, 0.5)) * 2;
            float signedDistance = radius - 1.0;
            float gradient = fwidth(signedDistance);
            float rangeFromLine = abs((signedDistance) / gradient);
            float lineWeight = clamp(1 - rangeFromLine, 0.0, 1.0);
            vec4 color = mix(c, vec4(0.0, 0.0, 0.0, 0.0), lineWeight);
            if (radius > 1) color.a = 0;
            gl_FragColor = color;
        }
    '''

    def __init__(self):
        self.shader = gpu.types.GPUShader(self.vertex_shader, self.fragment_shader)

    def set_locations(self, locations, colors):
        self.batch = batch_for_shader(self.shader, 'POINTS', {"pos": locations, "color": colors})

    def draw(self):
        view_project_matrix = bpy.context.region_data.perspective_matrix

        self.shader.bind()
        self.shader.uniform_float("viewProjectionMatrix", view_project_matrix)

        bgl.glEnable(bgl.GL_BLEND)
        bgl.glDisable(bgl.GL_DEPTH_TEST)
        bgl.glPointSize(8)
        self.batch.draw(self.shader)
        bgl.glEnable(bgl.GL_DEPTH_TEST)
        bgl.glDisable(bgl.GL_BLEND)


class Lines:

    def __init__(self):
        self.color = (0.8, 0.8, 0.8, 0.8)
        self.shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
        self.indices = ((0, 1), (0, 2), (1, 3), (2, 3),
                        (4, 5), (4, 6), (5, 7), (6, 7),
                        (0, 4), (1, 5), (2, 6), (3, 7))

    def set_color(self, color):
        self.color = color

    def set_vertices(self, vertices):
        self.batch = batch_for_shader(self.shader, 'LINES', {"pos": vertices}, indices=self.indices)

    def draw(self):
        view_project_matrix = bpy.context.region_data.perspective_matrix

        self.shader.bind()
        self.shader.uniform_float("color", self.color)

        bgl.glEnable(bgl.GL_BLEND)
        bgl.glDisable(bgl.GL_DEPTH_TEST)
        self.batch.draw(self.shader)
        bgl.glEnable(bgl.GL_DEPTH_TEST)
        bgl.glDisable(bgl.GL_BLEND)
