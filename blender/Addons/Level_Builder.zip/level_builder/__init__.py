from . import ui
from . import selector
from . import batch_import
from . import generate_preview
from . import replace_materials
from . import rigid_body_helper

bl_info = {
    "name": "Level Builder",
    "author": "Kenneth",
    "description": "Fast asset picking and placing for level design.",
    "version": (1, 0),
    "blender": (2, 80, 0),
    "location": "View3D",
    "category": "Object"
}


def register():
    ui.register()
    selector.register()
    batch_import.register()
    generate_preview.register()
    replace_materials.register()
    rigid_body_helper.register()


def unregister():
    ui.unregister()
    selector.unregister()
    batch_import.unregister()
    generate_preview.unregister()
    replace_materials.unregister()
    rigid_body_helper.unregister()

if __name__ == "__main__":
    register()
