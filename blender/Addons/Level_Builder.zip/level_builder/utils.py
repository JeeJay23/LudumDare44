import os
import math
import bpy
import bmesh
import mathutils
from mathutils import Vector, Quaternion, Matrix
from mathutils.bvhtree import BVHTree
from bpy_extras import view3d_utils


def iter_parent_children_in(objs):
    parents = (obj for obj in objs if obj.parent is None)
    for parent in parents:
        yield parent, [obj for obj in objs if get_parent_root(obj) == parent or obj == parent]


def get_parent_root(obj):
    while obj.parent is not None:
        obj = obj.parent
    return obj


def copy_objects_in(objs):
    clone_map = {}
    for obj in objs:
        clone = obj.copy()
        clone_map[obj] = clone
    for obj, clone in clone_map.items():
        if obj.parent is not None and obj.parent in clone_map:
            clone.parent = clone_map[obj.parent]
    return list(clone_map.values())


def remove_objects_in(objs):
    for obj in objs:
        obj.use_fake_user = False
        bpy.data.objects.remove(obj)


def get_collection(name, collection=None):
    if collection is None:
        collection = bpy.context.scene.collection
    if name in collection.children:
        return collection.children[name]
    else:
        col = bpy.data.collections.new(name)
        collection.children.link(col)
        return col


def move_to_collections(objs, *collections):
    master = bpy.context.scene.collection
    for obj in objs:
        if obj in master.objects.values():
            master.objects.unlink(obj)
        for col in obj.users_collection:
            col.objects.unlink(obj)
        for col in collections:
            col.objects.link(obj)


def get_objects_extends(objs):
    v_min = Vector((1e24, 1e24, 1e24))
    v_max = Vector((-1e24, -1e24, -1e24))

    for obj in objs:
        matrix = obj.matrix_world
        if obj.type != 'MESH':
            v1 = matrix @ Vector((-0.1, -0.1, -0.1))
            v2 = matrix @ Vector((0.1, 0.1, 0.1))
        else:
            bb = [matrix @ Vector((v[0], v[1], v[2])) for v in obj.bound_box]
            bb.append(matrix @ Vector((0.0, 0.0, 0.0)))
            x = [v.x for v in bb]
            y = [v.y for v in bb]
            z = [v.z for v in bb]
            v1 = Vector((min(*x), min(*y), min(*z)))
            v2 = Vector((max(*x), max(*y), max(*z)))

        v_min.x = v1.x if v1.x < v_min.x else v_min.x
        v_min.y = v1.y if v1.y < v_min.y else v_min.y
        v_min.z = v1.z if v1.z < v_min.z else v_min.z
        v_max.x = v2.x if v2.x > v_max.x else v_max.x
        v_max.y = v2.y if v2.y > v_max.y else v_max.y
        v_max.z = v2.z if v2.z > v_max.z else v_max.z

    return v_min, v_max


def apply_object_and_children(parent, objs):
    bpy.ops.object.select_all(action='DESELECT')
    bpy.context.view_layer.objects.active = parent
    for obj in objs:
        obj.select_set(True)
    bpy.ops.object.transform_apply(location=False, scale=True, rotation=True)
    bpy.ops.object.parent_clear(type='CLEAR_INVERSE')


def align_object_to_grid(parent, objs, align, index, row, pos, size):
        index = 0 if not align else index
        loc = Vector((index % row, int(index / row), 0))

        v_min, v_max = get_objects_extends(objs)
        if v_min == v_max:
            return

        dim = 0.9 / max(abs(v_max.x - v_min.x), abs(v_max.y - v_min.y), abs(v_max.z - v_min.z))
        scale = dim if size else 1

        center = (v_min + v_max) * 0.5
        magnitude = (center - v_max).magnitude

        offset = center * scale
        offset.z = v_min.z * scale

        if pos:
            loc -= offset
            center = Vector((0, 0, (center.z - v_min.z) * scale))
        parent.location = loc

        if size:
            parent.scale *= dim
            magnitude *= dim

        return center, magnitude


def align_rotation(align, to):
    if align == -1:
        return Quaternion()
    align_vector = ((1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0), (-1.0, 0.0, 0.0), (0.0, -1.0, 0.0), (0.0, 0.0, -1.0))
    align_vector = Vector(align_vector[align])
    angle = align_vector.angle(to)
    if align_vector.cross(to.normalized()).length_squared < 0.1:
        if align in (0, 1, 3, 4):
            return Quaternion(Vector((0.0, 0.0, 1.0)), angle)
    return align_vector.rotation_difference(to)


def get_viewport_eye_location():
    region_3d = bpy.context.space_data.region_3d
    pos = region_3d.view_matrix.inverted().translation
    return pos


def get_viewport_eye_direction():
    region_3d = bpy.context.space_data.region_3d
    vd = region_3d.view_matrix.to_quaternion() @ Vector((0.0, 0.0, -1.0))
    return vd


def get_viewport_location(x, y, dist):
    region = bpy.context.region
    region_3d = bpy.context.space_data.region_3d
    vo = view3d_utils.region_2d_to_origin_3d(region, region_3d, (x, y))
    vd = view3d_utils.region_2d_to_vector_3d(region, region_3d, (x, y))
    pos = vo + dist * vd
    return pos


def get_point_in_plane(x, y, plane_co, plane_no):
    ro, rd = get_ray(x, y)
    end = ro + rd * bpy.context.space_data.clip_end
    point = mathutils.geometry.intersect_line_plane(ro, end, plane_co, plane_no)
    angle = rd.angle(point - ro, 0)
    point = None if angle >= math.pi / 2 else point
    return point


def get_distance_to_plane(point, plane_co, plane_no):
    dist = mathutils.geometry.distance_point_to_plane(point, plane_co, plane_no)
    return abs(dist)


def get_ray(x, y):
    region = bpy.context.region
    region_3d = bpy.context.space_data.region_3d
    ro = view3d_utils.region_2d_to_origin_3d(region, region_3d, (x, y))
    rd = view3d_utils.region_2d_to_vector_3d(region, region_3d, (x, y))
    return ro, rd


def view_3d_to_2d(loc):
    region = bpy.context.region
    region_3d = bpy.context.space_data.region_3d
    loc = view3d_utils.location_3d_to_region_2d(region, region_3d, loc)
    return loc


def get_bpy_area(area_type):
    for window in bpy.context.window_manager.windows:
        screen = window.screen
        for area in screen.areas:
            if area.type == area_type:
                return area


def get_bvhtree(objs):
    bm = bmesh.new()
    matrix = Matrix.Identity(4)
    transform = bm.transform
    from_object = bm.from_object
    depsgraph = bpy.context.depsgraph
    for obj in objs:
        matrix_world = obj.matrix_world
        transform(matrix_world.inverted_safe() @ matrix)
        from_object(obj, depsgraph)
        matrix = matrix_world
    transform(matrix)
    bm.normal_update()
    bvhtree = BVHTree.FromBMesh(bm)
    bm.free()
    return bvhtree
