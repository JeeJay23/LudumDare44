import os
import bpy
from mathutils import Vector
from . import utils


class LB_BatchImportSettings(bpy.types.PropertyGroup):

    path: bpy.props.StringProperty(name="Import Path", subtype='DIR_PATH')
    rename_object: bpy.props.BoolProperty(name="Rename Object", default=False)
    rename_mesh: bpy.props.BoolProperty(name="Rename Mesh", default=False)
    rotation: bpy.props.FloatVectorProperty(name="Rotation", subtype='EULER')
    scale: bpy.props.FloatProperty(name="Scale", default=1.0)
    override: bpy.props.BoolProperty(name="Override Transform", default=False)
    apply: bpy.props.BoolProperty(name="Apply Transform", default=True)
    grid: bpy.props.BoolProperty(name="Align to grid", default=True)
    pos: bpy.props.BoolProperty(name="Adjust Location", default=True)
    size: bpy.props.BoolProperty(name="Adjust Size", default=True)
    row: bpy.props.IntProperty(name="Row", default=10)
    restart: bpy.props.BoolProperty(name="Restart", default=False)


class LB_BatchImportPanel(bpy.types.Panel):

    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_label = "Batch Import"
    bl_category = "Level Builder"
    bl_context = 'objectmode'

    def draw(self, context):
        layout = self.layout
        settings = context.scene.lb_batch_import

        column = layout.column(align=True)
        column.prop(settings, "path", text="")
        column.operator(LB_BatchImport.bl_idname, icon='DUPLICATE')

        box = layout.box()
        column = box.column(align=True)
        column.prop(settings, "rename_object")
        column.prop(settings, "rename_mesh")

        box = layout.box()
        column = box.column(align=True)
        column.prop(settings, "override")
        column2 = column.column()
        column2.active = settings.override
        column2.prop(settings, "rotation")
        column2.prop(settings, "scale")
        column.prop(settings, "apply")

        box = layout.box()
        column = box.column(align=True)
        column.prop(settings, "grid")
        column2 = column.column(align=True)
        column2.active = settings.grid
        column2.prop(settings, "row")
        column2.prop(settings, "pos")
        column2.prop(settings, "size")
        column2.prop(settings, "restart", text="Restart Collection")
        column.operator(LB_RearrangeObjects.bl_idname, icon='CENTER_ONLY')


class LB_RearrangeObjects(bpy.types.Operator):

    bl_idname = "lb.rearrange_objects"
    bl_label = "Rearrange"
    bl_description = "Rearrange objects in collection"

    def execute(self, context):
        collection = bpy.context.view_layer.active_layer_collection.collection
        rearrange_objects(collection)
        return {'FINISHED'}


class LB_BatchImport(bpy.types.Operator):

    bl_idname = "lb.batch_import"
    bl_label = "Import"
    bl_description = "Batch import multiple asset from path"

    @classmethod
    def poll(cls, context):
        path = bpy.context.scene.lb_batch_import.path
        path = bpy.path.abspath(path)
        return os.path.exists(path)

    def execute(self, context):
        path = bpy.context.scene.lb_batch_import.path
        path = bpy.path.abspath(path)

        materials = {}
        collection = utils.get_collection("Imported")
        import_files(path, collection, materials)
        rearrange_objects(collection)

        for name, mat in materials.items():
            mat.name = name

        return {'FINISHED'}


def import_files(path, collection, materials):
    types = ("fbx", "obj", "3ds", "blend")
    items = sorted(os.listdir(path))
    folders = []

    for item in items:
        dir_path = os.path.join(path, item)
        if os.path.isdir(dir_path):
            folders.append(item)
            continue

        for ext in types:
            if item.lower().endswith(".{}".format(ext)):
                name = os.path.splitext(item)[0]
                file_path = os.path.join(path, item)
                objs = import_file(file_path, ext)
                manage_object(objs, name, collection, materials)

    for folder in folders:
        dir_path = os.path.join(path, folder)
        coll = bpy.data.collections.new(folder)
        collection.children.link(coll)
        import_files(dir_path, coll, materials)


def manage_object(objs, name, collection, materials):
    settings = bpy.context.scene.lb_batch_import

    utils.move_to_collections(objs, collection)

    for obj in objs:
        if settings.rename_object:
            obj.name = name
        if settings.rename_mesh and obj.type == 'MESH':
            obj.data.name = obj.name

        for slot in obj.material_slots:
            mat = slot.material
            if slot.material in materials.values():
                continue
            if slot.material.name in materials:
                slot.material = materials[slot.material.name]
                if mat.users == 0:
                    bpy.data.materials.remove(mat)
            else:
                materials[slot.material.name] = mat
                mat.name = mat.name + ".temp"

    for parent, children in utils.iter_parent_children_in(objs):
        if settings.override:
            parent.rotation_euler = settings.rotation
            parent.scale = Vector((settings.scale, settings.scale, settings.scale))
            bpy.context.scene.update()

        if settings.apply:
            utils.apply_object_and_children(parent, children)


def import_file(file, ext):
    objs = []
    bpy.ops.object.select_all(action='DESELECT')

    try:
        if ext == "fbx":
            if hasattr(bpy.types, bpy.ops.import_scene.fbx.idname()):
                bpy.ops.import_scene.fbx(filepath=file)
                objs = bpy.context.selected_objects

        elif ext == "obj":
            if hasattr(bpy.types, bpy.ops.import_scene.obj.idname()):
                bpy.ops.import_scene.obj(filepath=file)
                objs = bpy.context.selected_objects

        elif ext == "3ds":
            if hasattr(bpy.types, bpy.ops.import_scene.autodesk_3ds.idname()):
                bpy.ops.import_scene.autodesk_3ds(filepath=file)
                objs = bpy.context.selected_objects

        elif ext == "blend":
            with bpy.data.libraries.load(file, link=False) as (data_from, data_to):
                data_to.objects = data_from.objects
                objs = data_to.objects

    except Exception as e:
        print(str(e))

    bpy.ops.object.select_all(action='DESELECT')
    return objs


def rearrange_objects(collection, count=0):
    settings = bpy.context.scene.lb_batch_import
    if settings.restart:
        count = 0

    parent_children_list = list(utils.iter_parent_children_in(collection.objects))

    for parent, _ in parent_children_list:
        parent.location = Vector((0, 0, 0))
        parent.scale = Vector((1, 1, 1))
    bpy.context.scene.update()

    for parent, children in sorted(parent_children_list, key=lambda x: x[0].name):
        utils.align_object_to_grid(parent, children, settings.grid, count, settings.row, settings.pos, settings.size)
        count += 1

    for col in collection.children:
        count = rearrange_objects(col, count)

    return count


classes = (
    LB_BatchImportSettings,
    LB_BatchImportPanel,
    LB_BatchImport,
    LB_RearrangeObjects
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.lb_batch_import = bpy.props.PointerProperty(type=LB_BatchImportSettings)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.lb_batch_import
