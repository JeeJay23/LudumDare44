import bpy
from . import utils


class LB_RigidBodyHelperSettings(bpy.types.PropertyGroup):

    dynamic_objects: bpy.props.PointerProperty(name="Dynamic Objects", type=bpy.types.Collection)
    dynamic_objects_shape: bpy.props.EnumProperty(name="Dynamic Objects Shape", items=[("MESH", "Mesh", "", "MESH_MONKEY", 0),
                                                                                       ("CONVEX_HULL", "Convex Hull", "", "MESH_ICOSPHERE", 1),
                                                                                       ("BOX", "Box", "", "MESH_CUBE", 2)])
    dynamic_objects_margin: bpy.props.FloatProperty(name="Dynamic Objects Margin", default=0.04)
    static_objects: bpy.props.PointerProperty(name="Static Objects", type=bpy.types.Collection)
    static_objects_shape: bpy.props.EnumProperty(name="Static Objects Shape", items=[("MESH", "Mesh", "", "MESH_MONKEY", 0),
                                                                                     ("CONVEX_HULL", "Convex Hull", "", "MESH_ICOSPHERE", 1),
                                                                                     ("BOX", "Box", "", "MESH_CUBE", 2)])
    static_objects_margin: bpy.props.FloatProperty(name="Static Objects Margin", default=0.04)

    split_impulse: bpy.props.BoolProperty(name="Split Impulse", description="Enable split impulse in rigid body world.")


class LB_RigidBodyHelperPanel(bpy.types.Panel):

    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_label = "Rigid Body Helper"
    bl_category = "Level Builder"
    bl_context = 'objectmode'

    def draw(self, context):
        layout = self.layout
        settings = context.scene.lb_rigid_body_helper

        column = layout.column()
        column.label(text="Dynamic Objects")
        column.prop(settings, "dynamic_objects", text="")
        column.prop(settings, "dynamic_objects_shape", text="")
        column.prop(settings, "dynamic_objects_margin", text="Margin")
        column.label(text="Static Objects")
        column.prop(settings, "static_objects", text="")
        column.prop(settings, "static_objects_shape", text="")
        column.prop(settings, "static_objects_margin", text="Margin")
        column.separator()
        column.prop(settings, "split_impulse")
        column.operator(LB_RigidBodyHelperStart.bl_idname, text="Create Proxy", icon='PHYSICS')
        column.operator(LB_RigidBodyHelperFinish.bl_idname, text="Finish", icon='FILE_TICK')


class LB_RigidBodyHelperStart(bpy.types.Operator):

    bl_idname = "lb.rigid_body_helper_start"
    bl_label = "Rigid Body Helper"
    bl_description = "Helper to create rigid body proxy objects"

    @classmethod
    def poll(cls, context):
        settings = context.scene.lb_rigid_body_helper
        global rigidbody_proxy
        return not (rigidbody_proxy or settings.dynamic_objects is None or settings.static_objects is None)

    def execute(self, context):
        global rigidbody_proxy, rigidbody_objects
        settings = context.scene.lb_rigid_body_helper

        rigidbody_proxy = True
        rigidbody_objects = {}

        if bpy.context.scene.rigidbody_world is not None:
            bpy.ops.rigidbody.world_remove()
        bpy.ops.rigidbody.world_add()
        bpy.context.scene.rigidbody_world.use_split_impulse = True

        coll = utils.get_collection("Level Builder Rigid Body")
        bpy.context.scene.rigidbody_world.collection = coll
        bpy.context.scene.frame_set(1)

        active = None
        objs = (obj for obj in settings.static_objects.objects if obj.type == 'MESH')
        bpy.ops.object.select_all(action='DESELECT')
        for obj in objs:
            coll.objects.link(obj)
            obj.select_set(True)
            if active is None:
                active = obj

        if active is not None:
            bpy.context.view_layer.objects.active = active
            bpy.ops.rigidbody.object_add(type='PASSIVE')
            bpy.ops.rigidbody.shape_change(type=settings.static_objects_shape)
            active.rigid_body.use_margin = True
            active.rigid_body.collision_margin = settings.static_objects_margin
            bpy.ops.rigidbody.object_settings_copy()

        share_mesh = {}
        share_join_mesh = {}
        for parent, children in utils.iter_parent_children_in(settings.dynamic_objects.objects):
            objs = (obj for obj in children if obj.type == 'MESH' and obj.visible_get())
            objs = utils.copy_objects_in(objs)
            if len(objs) == 0:
                continue

            for obj in children:
                obj.hide_viewport = True

            bpy.ops.object.select_all(action='DESELECT')
            for obj in objs:
                coll.objects.link(obj)
                obj.select_set(True)

            active = objs[0]
            mesh = share_mesh.get(active.data)
            if mesh is None:
                mesh = active.data.copy()
                share_mesh[active.data] = mesh
            active.data = mesh

            bpy.context.view_layer.objects.active = active
            if len(objs) > 1:
                join_obj = frozenset([obj.data for obj in objs])
                join_mesh = share_join_mesh.get(join_obj)
                if join_mesh is None:
                    for obj in objs:
                        matrix = obj.matrix_world.copy()
                        obj.parent = None
                        obj.matrix_world = matrix
                    active.data = active.data.copy()
                    bpy.ops.object.join()
                    share_join_mesh[join_obj] = active.data
                else:
                    active.data = join_mesh

                for obj in objs:
                    if obj == active:
                        continue
                    bpy.data.objects.remove(obj)

            origin = bpy.data.objects.new(active.name + "_origin", None)
            origin.empty_display_size = 0.01
            origin.parent = active
            coll.objects.link(origin)
            rigidbody_objects[active] = parent, children, origin

        for mesh in share_mesh.values():
            if mesh.users == 0:
                bpy.data.meshes.remove(mesh)

        active = None
        bpy.ops.object.select_all(action='DESELECT')
        for obj in rigidbody_objects:
            obj.select_set(True)
            if active is None:
                active = obj

        if active is not None:
            bpy.context.view_layer.objects.active = active
            bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_VOLUME', center='MEDIAN')
            bpy.ops.rigidbody.object_add(type='ACTIVE')
            bpy.ops.rigidbody.shape_change(type=settings.dynamic_objects_shape)
            active.rigid_body.use_margin = True
            active.rigid_body.collision_margin = settings.dynamic_objects_margin
            bpy.ops.rigidbody.object_settings_copy()

        for proxy, (parent, children, origin) in rigidbody_objects.items():
            origin.matrix_world = parent.matrix_world

        bpy.ops.object.select_all(action='DESELECT')

        return {'FINISHED'}


class LB_RigidBodyHelperFinish(bpy.types.Operator):

    bl_idname = "lb.rigid_body_helper_finish"
    bl_label = "Rigid Body Helper Finish"
    bl_description = "Copy rigid body proxy objects data back to original objects"

    @classmethod
    def poll(cls, context):
        global rigidbody_proxy
        return rigidbody_proxy

    def execute(self, context):
        global rigidbody_proxy, rigidbody_objects

        rigidbody_proxy = False
        coll = utils.get_collection("Level Builder Rigid Body")

        for proxy, (parent, children, origin) in rigidbody_objects.items():
            for obj in children:
                obj.hide_viewport = False
            parent.matrix_world = origin.matrix_world.copy()

            proxy.rigid_body.enabled = False
            coll.objects.unlink(proxy)
            coll.objects.unlink(origin)

        for obj in coll.objects:
            obj.rigid_body.enabled = False

        bpy.context.scene.rigidbody_world.collection = None
        bpy.ops.rigidbody.world_remove()
        bpy.context.scene.collection.children.unlink(coll)
        bpy.data.collections.remove(coll)

        for proxy, (parent, children, origin) in rigidbody_objects.items():
            origin.parent = None
            bpy.data.objects.remove(origin)
            mesh = proxy.data
            bpy.data.objects.remove(proxy)
            if mesh.users == 0:
                bpy.data.meshes.remove(mesh)

        bpy.context.scene.frame_set(1)
        rigidbody_objects = {}

        return {'FINISHED'}


rigidbody_proxy = False
rigidbody_objects = {}

classes = (
    LB_RigidBodyHelperSettings,
    LB_RigidBodyHelperStart,
    LB_RigidBodyHelperFinish,
    LB_RigidBodyHelperPanel
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.lb_rigid_body_helper = bpy.props.PointerProperty(type=LB_RigidBodyHelperSettings)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.lb_rigid_body_helper
