import sys
from contextlib import contextmanager
import bpy
from mathutils import Vector, Matrix
from . import utils


class RayCast:

    def __init__(self):
        self.reset()

    def reset(self):
        self.scene_bvhtree = None

    def iter_all_objects_in(self, objs, exclude_objs):
        for obj in objs:
            if obj.instance_type == 'COLLECTION':
                yield from self.iter_all_objects_in(obj.instance_collection.all_objects, exclude_objs)

            if obj.type == 'MESH' and obj not in exclude_objs:
                yield obj

    def get_scene_bvhtree(self, objs):
        if self.scene_bvhtree is not None:
            return self.scene_bvhtree
        self.scene_bvhtree = utils.get_bvhtree(objs)
        return self.scene_bvhtree

    # def scene_ray_cast(self, objs, ray_org, ray_dir, dist=1.70141e+38):
    #     bvhtree = self.get_scene_bvhtree(objs)
    #     location, normal, index, distance = bvhtree.ray_cast(ray_org, ray_dir, dist)
    #     hit = location is not None
    #     return hit, location, normal

    def scene_ray_cast(self, ray_org, ray_dir, dist=1.70141e+38):
        hit, location, normal, *_ = bpy.context.scene.ray_cast(bpy.context.view_layer, ray_org, ray_dir, distance=dist)
        return hit, location, normal

    def hit(self, x, y, exclude_objs):
        with scale_objects(exclude_objs, (0, 0, 0)):
            ray_org, ray_dir = utils.get_ray(x, y)
            return self.scene_ray_cast(ray_org, ray_dir)

    def scatter(self, x, y, radius, locations, exclude_objs):
        settings = bpy.context.scene.level_builder.builder

        with scale_objects(exclude_objs, (0, 0, 0)):
            ray_org, ray_dir = utils.get_ray(x, y)
            hit, hit_location, hit_normal = self.scene_ray_cast(ray_org, ray_dir)
            if not hit:
                return None, None, []

            objs = self.iter_all_objects_in(bpy.context.visible_objects, exclude_objs)
            scatters = []

            for loc in locations:
                scatter_normal = hit_normal
                if int(settings.paint_project_normal) == 1:
                    scatter_normal = -Vector(settings.paint_project_custom)

                q = Vector((0.0, 0.0, 1.0)).rotation_difference(scatter_normal)
                loc = hit_location + (q @ loc if settings.paint_sphere else loc)

                if radius < 0.01:
                    location, normal = hit_location, hit_normal
                elif int(settings.paint_mode) == 1:
                    location, normal = self.scatter_nearest(objs, loc, radius)
                else:
                    location, normal = self.scatter_project(loc, scatter_normal, radius)
                    if location is None and settings.paint_no_discard_missed:
                        location, normal = self.scatter_nearest(objs, loc, radius)
                scatters.append((location, normal))

            return hit_location, hit_normal, scatters

    def scatter_project(self, loc, nor, radius):
        ray_org = loc + nor * radius * 0.9
        ray_dir = -nor
        hit, location, normal = self.scene_ray_cast(ray_org, ray_dir, radius * 2)
        if not hit:
            location = normal = None
        return location, normal

    def scatter_nearest(self, objs, loc, radius):
        bvhtree = self.get_scene_bvhtree(objs)
        location, normal, index, distance = bvhtree.find_nearest(loc)
        return location, normal

ray_cast = RayCast()
reset = ray_cast.reset
hit = ray_cast.hit
scatter = ray_cast.scatter


@contextmanager
def scale_objects(objs, scale):
    scale_dict = {obj: obj.scale.copy() for obj in objs}
    for obj in objs:
        obj.scale = scale
    bpy.context.scene.update()
    yield None
    for obj in objs:
        obj.scale = scale_dict[obj]
